local ItemManager = sdk.get_managed_singleton("app.ItemManager")
local CharacterManager = sdk.get_managed_singleton("app.CharacterManager")
local startup = require("_NickCore/Startup")
local fns = require("_NickCore/Functions")
local config = require("diacyst/Config/ESO")
local configMSI = (MSI_installed and require("diacyst/Config/MSI")) or nil
local configUDD2P = (UDD2P_installed and require("UDD2P/Config")) or nil
local configGPO = (GPO_installed and require("GPO/Config")) or nil
local constants = require("diacyst/Constants/ESO")

local vocationList = constants.vocationList
local itemCategory = constants.itemCategory
local itemSubCategory = constants.itemSubCategory
local equipCategory = constants.equipCategory
local smithingStyle = constants.smithingStyle
local upgradeLevel = constants.upgradeLevel
local elementType = constants.elementType
local armorType = constants.armorType
local offensiveStats = constants.offensiveStats
local defensiveStats = constants.defensiveStats
local effectParamsBody = constants.effectParamsBody
local effectParamsMind = constants.effectParamsMind
local resParamsDef = constants.resParamsDef
local resParamsResBody = constants.resParamsResBody
local resParamsResMind = constants.resParamsResMind
local matParamList = constants.matParamList
local wlcWeapons = constants.wlcWeapons
local wlcWeaponsExtra = constants.wlcWeaponsExtra
local wlcArmor = constants.wlcArmor
local wlcArmorExtra = constants.wlcArmorExtra
local weaponStatMults = constants.weaponStatMults
local armorStatMults = constants.armorStatMults
local secondaryStatMults = constants.secondaryStatMults                    
local matAssignIndices = constants.matAssignIndices
local matTypes = constants.matTypes
local matTraits = constants.matTraits
local bossMats = constants.bossMats
local abundantMats = constants.abundantMats

local markUpgradableMisc = config.PROVIDE_ENHANCE_DATA_FOR_NON_UPGRADABLE_GEAR and config.INCLUDE_MISC_GEAR
local markRecalculateCosts = not config.USE_BASIC_STAT_COMPUTATION and config.RECALCULATE_UPGRADE_COSTS
local maxLv = config.MAX_LEVEL
local lvT2 = config.T2_MIN_LEVEL
local lvT3 = config.T3_MIN_LEVEL
local advJobLv = config.ADVANCED_VOCATION_MIN_LEVEL
local maxGap = (config.UNEQUALIZE_FINAL_STATS and config.MAX_GAP) or 0
local enchantRate = config.ENCHANT_RATE
local statAdj = config.STAT_ADJUST_RATE
local wyrmfireStatBonus = config.WYRMFIRE_STAT_BONUS		
local resPhys = config.MAX_RES_PHYS
local resElement = config.MAX_RES_ELEMENT
local resStatus = config.MAX_RES_STATUS
local curesSellMult = (GPO_installed and configGPO.CURATIVES_SELL_PRICE_MULT) or 1
local matsSellMult = (GPO_installed and configGPO.MATERIALS_SELL_PRICE_MULT) or 1
local othersSellMult = (GPO_installed and configGPO.OTHER_IMPLEMENTS_SELL_PRICE_MULT) or 1
local gearBuyMult = (GPO_installed and configGPO.GEAR_BUY_PRICE_MULT) or 1
local gearSellMult = (GPO_installed and configGPO.GEAR_SELL_PRICE_MULT) or 1
local enhanceGoldMult = (GPO_installed and configGPO.ENHANCE_GOLD_MULT) or 1
local enhanceItemMult = (GPO_installed and configGPO.ENHANCE_ITEM_MULT) or 1

local weaponData = {}
local armorData = {}
local miscData = {}
local ringData = {}
local bestWeapons = {}
local bestArmor = {}
local bestMisc = {}
local bestRing = 0
local worstWeapons = {}
local worstArmor = {}
local bestWeaponStats = {}
local bestArmorStats = {}
local bestMiscStats = {}
local weaponLevels = {}
local armorLevels = {}
local miscLevels = {}
local ringLevels = {}
local weaponNowUpgradable = {}
local armorNowUpgradable = {}
local miscNowUpgradable = {}
local itemData = {}
local materialData = {}
local matTiers = {T1 = {}, T2 = {}, T3 = {}}
local vanillaGear = {}
local wlcWeaponsList = {}
local wlcArmorList = {}
local vocationListWS = {}
local smithingStyleNWF = {}
local effectParams = {}
local resParams = {}
local physCategory = {}
local elementCategory = {}
local statusCategory = {}

local function roundUp(num) return math.floor(num + 0.5) end
local function getDataById(id) return weaponData[id] or armorData[id] or miscData[id] or ringData[id] end
local function getEquipData(type) return (type == "Weapon" and weaponData) or (type == "Armor" and armorData) or (type == "Misc" and miscData) or (type == "Ring" and ringData) end
local function getNewResVal(currVal, newBase) return (currVal > 0 and newBase) or currVal end
local function checkStarter(job) return job == "Fighter" or job == "Fighter - Shield" or job == "Archer" or job == "Mage" or job == "Thief" end
local function checkMagickPrimary(job) return job == "Mage" or job == "Sorcerer" or job == "Magick Archer" or job == "Trickster" end

-- COMPAT: vanillaGear marks only IDs present in the original game's known lists.
-- When the expansion adds equipment records, they must not flow into ESO's
-- fixed vocation/category and best-in-slot tables.
local function prepareLists(equipDict)	
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value

		if itemCategory[param._Category] == "Equip" then
			local categorySub = equipCategory[param._EquipCategory]
			
			if categorySub == "Weapon" then
				local job = vocationList[param._Job]
				
				if job == "Fighter" then vanillaGear[id] = (id >= 1000 and id <= 1013) or (id >= 1100 and id <= 1104) or id == 8000
				elseif job == "Archer" then vanillaGear[id] = (id >= 1700 and id <= 1709) or (id >= 1800 and id <= 1805) or id == 8200
				elseif job == "Mage" then vanillaGear[id] = (id >= 1500 and id <= 1517) or id == 8150
				elseif job == "Thief" then vanillaGear[id] = (id >= 1400 and id <= 1417) or id == 8100
				elseif job == "Warrior" then vanillaGear[id] = (id >= 1200 and id <= 1208) or (id >= 1300 and id <= 1304)
				elseif job == "Sorcerer" then vanillaGear[id] = id >= 1600 and id <= 1612
				elseif job == "Mystic Spearhand" then vanillaGear[id] = id >= 2000 and id <= 2010
				elseif job == "Magick Archer" then vanillaGear[id] = id >= 1900 and id <= 1909
				elseif job == "Trickster" then vanillaGear[id] = id >= 2100 and id <= 2105
				end				
				-- An expansion or equipment mod may reuse a vanilla ID but change its vocation flag.
				-- Do not treat it as a Fighter/Archer/etc weapon unless the vocation is recognized.
				if not vocationList[param._Job] then
					if vanillaGear[id] then
						log.info(string.format("[ESO Base-Game Compat] SKIP weapon ID=%s, unexpected vocation flag=%s", tostring(id), tostring(param._Job)))
					end
					vanillaGear[id] = false
				end
			elseif categorySub == "Shield" then vanillaGear[id] = (id >= 2200 and id <= 2210) or id == 8050
			elseif categorySub == "Head" then vanillaGear[id] = (id >= 4000 and id <= 4135) or id == 10312
			elseif categorySub == "Body" then vanillaGear[id] = (id >= 5000 and id <= 5139) or id == 7000 or id == 10409
			elseif categorySub == "Legs" then vanillaGear[id] = (id >= 6000 and id <= 6124) or id == 7001 or id == 10512
			elseif categorySub == "Cloak" then vanillaGear[id] = id >= 3300 and id <= 3351
			elseif categorySub == "Face" then vanillaGear[id] = id >= 3400 and id <= 3415
			elseif categorySub == "Ring" then vanillaGear[id] = (id >= 3501 and id <= 3555) or id == 8600
			end
		end
	end
	
	for _, id in pairs(wlcWeapons) do wlcWeaponsList[id] = true end
	for _, id in pairs(wlcWeaponsExtra) do wlcWeaponsList[id] = true end
	for _, id in pairs(wlcArmor) do wlcArmorList[id] = true end
	for _, id in pairs(wlcArmorExtra) do wlcArmorList[id] = true end
	for i = 1, 9 do vocationListWS[i] = vocationList[2 ^ i] end
	for i = 1, 4 do smithingStyleNWF[i] = smithingStyle[i - 1] end
	for type, effect in pairs(effectParamsBody) do effectParams[type] = effect end
	for type, effect in pairs(effectParamsMind) do effectParams[type] = effect end
	for type, res in pairs(resParamsDef) do resParams[type] = res end
	for type, res in pairs(resParamsResBody) do resParams[type] = res end
	for type, res in pairs(resParamsResMind) do resParams[type] = res end
	
	for type, effect in pairs(effectParams) do		
		if type == "strikePwr" then physCategory[type] = true
		elseif type == "elementPwr" then elementCategory[type] = true
		else statusCategory[type] = true
		end
	end
	
	for type, res in pairs(resParams) do
		if type == "slashDef" or type == "strikeDef" or type == "faintRes" then physCategory[type] = true 
		elseif type == "fireDef" or type == "iceDef" or type == "thunderDef" or type == "lightDef" or type == "burnRes" or type == "freezeRes" then elementCategory[type] = true 
		else statusCategory[type] = true
		end
	end
	
	vocationListWS[10] = "Fighter - Shield"
end

-- COMPAT: the primary item loops below only operate on known vanillaGear.
-- "DISQUALIFY_MODDED_GEAR" alone is insufficient; upstream ESO v2.9.2 still
-- touched unknown IDs during rebalance, level calculation and data generation.
local function rebalanceEquipment(equipDict)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value
		local name = param:get_Name()
		local category = itemCategory[param._Category]

		if category == "Equip" and vanillaGear[id] == true and name ~= "Invalid" then
			local categorySub = equipCategory[param._EquipCategory]
			
			if categorySub == "Weapon" or categorySub == "Shield" then
				local strikePwrHammer = 150
				local strikePwrMace = 100
				
				-- Dowsing Spikes gets a 40% nerf to its base stats since it can be acquired very early - it's rather strong and its vanilla KDP is on par with Heaven's Key
				-- It also becomes thrice as expensive because its stats are on par with Bardiche Daggers plus it also has a unique effect
				if id == 1413 then 
					param._PhysicalAttack = roundUp(param._PhysicalAttack * 0.6)
					param._Shake = roundUp(param._Shake * 0.6)
					param._Blow = roundUp(param._Blow * 0.6)
					param._BuyPrice = roundUp(param._BuyPrice * 3)
					param._SellPrice = roundUp(param._SellPrice * 3)
				end
				
				if id == 1202 then -- War Blade becomes half slash/half blunt, due to its hammer-like tip, and it also gets half the strike power of hammers
					param._SlashRate = 50
					param._StrikeRate = 50
					param._StrikeStore = roundUp(strikePwrHammer * (param._StrikeRate / 100))
				end
				
				if id == 1206 then -- Cyclopean Thunder now has 50 elemental power and and the strike power of hammers
					param._ElementStore = 50
					param._StrikeStore = roundUp(strikePwrHammer * (param._StrikeRate / 100))
				end
				
				if id == 2002 then -- Fool's Prize becomes full blunt though it only receives half the strike power of maces
					param._SlashRate = 0
					param._StrikeRate = 100
					param._StrikeStore = roundUp(strikePwrMace / 2)
				end
				
				if id == 1102 then -- The Exalted gets an 80% boost to its base KDP, but its elemental power is reduced by 20%
					param._Shake = roundUp(param._Shake * 1.8)
					param._Blow = roundUp(param._Blow * 1.8)
					param._ElementStore = roundUp(param._ElementStore * 0.8)
				end
				
				if id == 1103 then -- Threaded Cudgel gets a 20% nerf to its base STR and KDP, but it becomes 40% lighter
					param._PhysicalAttack = roundUp(param._PhysicalAttack * 0.8)
					param._Shake = roundUp(param._Shake * 0.8)
					param._Blow = roundUp(param._Blow * 0.8)
					param._Weight = roundUp(param._Weight * 0.6)
				end
					
				if id == 2200 or id == 8050 then -- Round Shield and Superior Round Shield get a 50% boost to their base KDP
					param._Shake = roundUp(param._Shake * 1.5)
					param._Blow = roundUp(param._Blow * 1.5)
				end
				
				if id == 2207 then -- Dragon's Faith gets a 5% boost to its base KDG, but becomes 10% heavier and 10% more expensive
					param._ShakeGuard = roundUp(param._ShakeGuard * 1.05)
					param._BlowGuard = roundUp(param._BlowGuard * 1.05)
					param._Weight = roundUp(param._Weight * 1.1)
					param._BuyPrice = roundUp(param._BuyPrice * 1.1)
					param._SellPrice = roundUp(param._SellPrice * 1.1)
				end
				
				if id == 1009 or id == 1207 then -- Carnation gets a 15% boost to its Slash Strength while Dragon's Bite gets a 10% boost to its Slash Strength - both of them become 10% lighter
					param._SlashRate = (id == 1009 and 115) or 110
					param._Weight = roundUp(param._Weight * 0.9)
				end
				
				if id == 1101 or id == 1411 then -- Dragon's Vein gets a 40% boost to its base KDP, and Molten Fury gets a 20% nerf to its base KDP
					local kdpMult = (id == 1101 and 0.8) or 1.4
					
					param._Shake = roundUp(param._Shake * kdpMult)
					param._Blow = roundUp(param._Blow * kdpMult)
				end
				
				if id == 1414 then -- Heaven's Key gets a 10% nerf to its base MAG and a 20% nerf to its base KDP
					param._MagicAttack = roundUp(param._MagicAttack * 0.9)
					param._Shake = roundUp(param._Shake * 0.80)
					param._Blow = roundUp(param._Blow * 0.80)
				end
				
				if id == 1512 then -- Necrotic Shriek's gets a 50% boost to its base KDP and debilitation power
					param._Shake = roundUp(param._Shake * 1.5)
					param._Blow = roundUp(param._Blow * 1.5)
					param._SilentStore = roundUp(param._SilentStore * 1.5)
				end
				
				-- Legion's Might and Lion-Lord Archistaff get a 20% nerf to their base MAG, KDP, and KDG
				-- Lion-Lord Archistaff also becomes 20% cheaper
				if id == 1513 or id == 1612 then 
					param._MagicAttack = roundUp(param._MagicAttack * 0.8)
					param._Shake = roundUp(param._Shake * 0.8)
					param._Blow = roundUp(param._Blow * 0.8)
					param._ShakeGuard = roundUp(param._ShakeGuard * 0.8)
					param._BlowGuard = roundUp(param._BlowGuard * 0.8)
					
					if id == 1612 then
						param._BuyPrice = roundUp(param._BuyPrice * 0.8)
						param._SellPrice = roundUp(param._SellPrice * 0.8)
					end
				end
				
				-- Dragon's Flight is a battleaxe, so it becomes 80% slash/20% blunt, receiving 20% of the strike power of hammers
				-- It also gets a 10% nerf to its base STR and a 5% nerf to its base STR
				if id == 1303 then 
					param._PhysicalAttack = roundUp(param._PhysicalAttack * 0.9)
					param._Shake = roundUp(param._Shake * 0.95)
					param._Blow = roundUp(param._Blow * 0.95)
					param._SlashRate = 80
					param._StrikeRate = 20
					param._StrikeStore = roundUp(strikePwrHammer * (param._StrikeRate / 100))
				end	
				
				if id == 1907 then -- Blackwing Bow gets a 20% boost to its base MAG but gets a 20% nerf to its base KDP, and it also becomes 25% lighter
					param._MagicAttack = roundUp(param._MagicAttack * 1.2)
					param._Shake = roundUp(param._Shake * 0.8)
					param._Blow = roundUp(param._Blow * 0.8)
					param._Weight = roundUp(param._Weight * 0.75)
				end
				
				if id == 2209 then -- Dragon's Aegis gets stamina reduction equal to Lustrous Targe's and becomes 25% lighter
					param._StaminaReduce = 5
					param._Weight = roundUp(param._Weight * 0.75)
				end
				
				-- Wooden Staff and Superior Round Shield get a 30% boost to their base KDG
				-- Grievous Horn gets a 50% boost to its base KDG
				-- Round Shield gets a 20% boost to its base KDG
				-- Superior Wooden Staff gets a 5% nerf to its base KDG
				if id == 1500 or id == 1600 or id == 2200 or id == 8050 or id == 8150 then
					local kdgMult = (id == 1600 and 1.5) or (id == 2200 and 1.2) or (id == 8150 and 0.95) or 1.3
					
					param._ShakeGuard = roundUp(param._ShakeGuard * kdgMult)
					param._BlowGuard = roundUp(param._BlowGuard * kdgMult)
				end
				
				-- Dragon's Rancor gets a 20% boost to its base STR, Hydra Husk gets a 10% nerf to its base STR, and Dread Aspis gets a 25% boost to its base STR
				-- Rhewynt and Achromic Reverie get a 10% boost to their base MAG
				-- All shields now have strike power, equal to half of what maces have - Dread Aspis gets triple boosted, Dragon's Faith gets double boosted, and Dragon's Aegis gets a 50% boost
				if id == 1706 or id == 1805 or id == 2208 then param._PhysicalAttack = roundUp(param._PhysicalAttack * ((id == 1706 and 1.2) or (id == 1805 and 0.9) or 1.25)) end
				if id == 2007 or id == 2104 then param._MagicAttack = roundUp(param._MagicAttack * 1.1) end
				if categorySub == "Shield" then param._StrikeStore = roundUp(strikePwrMace * ((id == 2208 and 1.5) or (id == 2207 and 1) or (id == 2209 and 0.75) or 0.5)) end
				
				if wlcWeaponsList[id] then -- All endgame weapons now have equal prices
					param._BuyPrice = roundUp(((categorySub == "Shield" and 40000) or 75000) * gearBuyMult)
					param._SellPrice = roundUp(((categorySub == "Shield" and 13340) or 25000) * gearSellMult)
				end
				
				if config.AGGRANDIZE_SMITHING_STYLES then -- All weapons' base effect power values are halved, if the Aggrandize Smithing Styles option is enabled
					for _, effect in pairs(effectParams) do
						if param[effect] > 0 then param[effect] = roundUp(param[effect] / 2) end
					end
				end
			end
			
			if categorySub == "Head" or categorySub == "Body" or categorySub == "Legs" then
				if id == 4119 or id == 5117 or id == 6117 then -- Marcher's Set gets buffed so it's no longer a pitiful excuse of protective gear for the Vermundian Military
					local statMult = (id == 4119 and 3) or (id == 5117 and 6) or 4
					
					param._PhysicalDefence = roundUp(param._PhysicalDefence * statMult)
					param._MagicDefence = roundUp(param._MagicDefence * statMult)
					param._ShakeResistRate = roundUp(param._ShakeResistRate * statMult)
					param._BlowResistRate = roundUp(param._BlowResistRate * statMult)
					param._BuyPrice = roundUp(param._BuyPrice * statMult)
					param._SellPrice = roundUp(param._SellPrice * statMult)
				end
				
				if id == 5116 then -- Charming Corset gets a 40% nerf to its base stats, but it becomes 20% lighter and gets resistance bonuses similar to DDDA's Set of Queen's Clothing
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 0.6)
					param._MagicDefence = roundUp(param._MagicDefence * 0.6)
					param._ShakeResistRate = roundUp(param._ShakeResistRate * 0.6)
					param._BlowResistRate = roundUp(param._BlowResistRate * 0.6)
					param._Weight = roundUp(param._Weight * 0.8)
					param._SlashDefenceRate = 8
					param._StrikeDefenceRate = 10
					param._FireDefence = 12
					param._IceDefence = 12
					param._ThunderDefence = 0
					param._LightDefence = 0
					param._FireResist = 12
					param._IceResist = 12
					param._PoisonResist = 30
					param._SleepResist = 0
					param._SilentResist = 28
					param._StoneResist = 38
					param._WaterResist = 0
					param._OilResist = 0
					param._FaintResist = 0
				end
				
				if id == 4130 then -- Twilight Star gets a 40% nerf to its DEF and MDF stats, plus it becomes 150% more expensive
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 0.6)
					param._MagicDefence = roundUp(param._MagicDefence * 0.6)
					param._BuyPrice = roundUp(param._BuyPrice * 2.5)
					param._SellPrice = roundUp(param._SellPrice * 2.5)
				end
				
				if id == 4087 then -- Cavalier Hat gets a 25% nerf to its base KDR and loses its poison and sleep resistances in favor of fire, burn, and wet resistances
					param._ShakeResistRate = roundUp(param._ShakeResistRate * 0.75)
					param._BlowResistRate = roundUp(param._BlowResistRate * 0.75)
					param._FireDefence = 5
					param._FireResist = 5
					param._PoisonResist = 0
					param._SleepResist = 0
					param._WaterResist = 5
				end
				
				if id == 4102 then -- Predator's Maw gets a 10% boost to its base DEF and a 25% boost to its base KDR, because it's metallic, plus its resistances are boosted to 5%
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 1.1)
					param._ShakeResistRate = roundUp(param._ShakeResistRate * 1.25)
					param._BlowResistRate = roundUp(param._BlowResistRate * 1.25)
					param._PoisonResist = 5
					param._SleepResist = 5
					param._SilentResist = 5
				end
				
				if id == 4026 or id == 6026 then -- Blazing Soul becomes 10% heavier, while Executioner's Greaves gets a 10% nerf to its base MDF, and both of them gain fire and burn resistances
					if id == 4026 then param._Weight = roundUp(param._Weight * 1.1) end
					if id == 6026 then param._MagicDefence = roundUp(param._MagicDefence * 0.95) end
					
					param._FireDefence = 10
					param._FireResist = 10
				end
				
				if id == 4062 then -- Promethean Hood gets a 10% boost to its base DEF and its silence resistance is boosted to 10%, but it becomes 20% heavier
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 1.1)
					param._Weight = roundUp(param._Weight * 1.2)
					param._SilentResist = 10
				end
				
				-- Living Altar gets a 10% boost to its base DEF and KDR, and gains more slash and strike resistance, but it becomes 40% heavier
				-- Summoner's Crown gets a 10% nerf to its base DEF and KDR, and loses some slash and strike resistance, but it becomes 30% lighter
				if id == 4071 or id == 4073 then
					local statMult = (id == 4071 and 1.1) or 0.9
					local wgtMult = (id == 4071 and 1.4) or 0.7
					
					param._PhysicalDefence = roundUp(param._PhysicalDefence * statMult)
					param._ShakeResistRate = roundUp(param._ShakeResistRate * statMult)
					param._BlowResistRate = roundUp(param._BlowResistRate * statMult)
					param._Weight = roundUp(param._Weight * wgtMult)
					param._SlashDefenceRate = 3
					param._StrikeDefenceRate = 3
				end
				
				-- Monarch's Crown, Knightly Brigandine, and Conqueror's Sabatons gain more slash and strike resistances
				-- Their fire, ice, burn, and freeze resistances are switched to light and faint resistances
				-- Knightly Brigandine and Conqueror's Sabatons get a 20% boost to their base MDF
				if id == 4014 or id == 5014 or id == 6014 then
					if id ~= 4014 then param._MagicDefence = roundUp(param._MagicDefence * 1.2) end
					
					param._SlashDefenceRate = 2 * ((id == 5014 and 2) or 1)
					param._StrikeDefenceRate = 2 * ((id == 5014 and 2) or 1)
					param._LightDefence = 5 * ((id == 5014 and 2) or 1)
					param._FaintResist = 5 * ((id == 5014 and 2) or 1)
					param._FireDefence = 0
					param._IceDefence = 0
					param._FireResist = 0
					param._IceResist = 0
				end
				
				if id == 5131 then -- Hyperboreal Lorica now has 10% ice and freeze resistance, and gains more slash resistance
					param._SlashDefenceRate = 5
					param._IceDefence = 10
					param._IceResist = 10
				end
				
				if id == 5051 then -- Sacral Robe gets a 15% boost to its base MDF and gains a bit of light resistance, but it gets a 10% nerf to its base KDR and loses its poison resistance
					param._MagicDefence = roundUp(param._MagicDefence * 1.15)
					param._ShakeResistRate = roundUp(param._ShakeResistRate * 0.9)
					param._BlowResistRate = roundUp(param._BlowResistRate * 0.9)
					param._LightDefence = 5
					param._PoisonResist = 0
				end
				
				if id == 5126 then -- Edified Vestment gets a 20% boost to its base KDR and gains a bit of poison and sleep resistance, but it loses some of its silence resistance
					param._ShakeResistRate = roundUp(param._ShakeResistRate * 1.2)
					param._BlowResistRate = roundUp(param._BlowResistRate * 1.2)
					param._PoisonResist = 6
					param._SleepResist = 6
					param._SilentResist = 18
				end
				
				if id == 5096 then -- Enshadowed Battle Garb gets a 10% boost to its base MDF, and gains poison, sleep, silence, and petrify resistance, but it gets a 10% nerf to its base DEF
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 0.9)
					param._MagicDefence = roundUp(param._MagicDefence * 1.1)
					param._PoisonResist = 5
					param._SleepResist = 5
					param._SilentResist = 5
					param._StoneResist = 5
				end
				
				-- Silhouette of Sorcery gets a 10% boost to its base KDR, but it gets a 10% nerf to its base MDF
				-- Cardinal Robe gets a 10% boost to its base MDF, but it gets a 10% nerf to its base KDR
				if id == 5060 or id == 5062 then
					param._MagicDefence = roundUp(param._MagicDefence * ((id == 5060 and 0.9) or 1.1))
					param._ShakeResistRate = roundUp(param._ShakeResistRate * ((id == 5060 and 1.1) or 0.9))
					param._BlowResistRate = roundUp(param._BlowResistRate * ((id == 5060 and 1.1) or 0.9))
				end
				
				if id == 5038 then -- Soaring Surcoat gains slash, strike, fire, burn, ice, and freeze resistance, but loses its poison and sleep resistance
					param._SlashDefenceRate = 1
					param._StrikeDefenceRate = 1
					param._FireDefence = 10
					param._IceDefence = 10
					param._FireResist = 20
					param._IceResist = 20
					param._PoisonResist = 0
					param._SleepResist = 0					
				end
				
				if id == 5039 then -- Duelist's Coat gains resistance to poison, sleep, petrify, and faint, but loses its fire, burn, ice, and freeze resistance
					param._PoisonResist = 10
					param._SleepResist = 10
					param._StoneResist = 10
					param._FaintResist = 10
					param._FireDefence = 0
					param._IceDefence = 0
					param._FireResist = 0
					param._IceResist = 0
				end
				
				if id == 5107 then -- Resonance Armor gains resistance to light, but gets a 10% nerf to its base DEF
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 0.9)
					param._LightDefence = 10
				end
				
				if id == 5114 then -- Godsbeast Scalecoat gets a 10% boost to its base DEF, but loses some strike resistance
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 1.1)
					param._StrikeDefenceRate = 4
				end
				
				if id == 5071 then -- Totemic Shroud gets a 10% boost to its base MDF, and gains some light resistance, but loses some strike and slash resistance
					param._MagicDefence = roundUp(param._MagicDefence * 1.1)
					param._LightDefence = 10
					param._SlashDefenceRate = 4
					param._StrikeDefenceRate = 4
				end
				
				if id == 5073 then -- Arch-Conjuror's Robe gets a 10% boost to its base DEF, but gets a 5% nerf to its base MDF and loses its resistance to silence
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 1.1)
					param._MagicDefence = roundUp(param._MagicDefence * 0.95)
					param._SilentResist = 0
				end
				
				if id == 6019 then -- Mettlesome Cuisses gets a 10% boost to its base DEF, but its fire and burn resistance is now -5%
					param._PhysicalDefence = roundUp(param._PhysicalDefence * 1.1)
					param._FireDefence = -5
					param._FireResist = -5
				end
				
				-- Assassin's Breeches gets a 10% boost to its base DEF and a 30% boost to its base KDR, but it becomes 40% heavier
				-- Cliff Leapers becomes 25% lighter, and gains resistance to tar, but it gets a 50% nerf to its base KDR
				if id == 6096 or id == 6103 then					
					if id == 6096 then param._PhysicalDefence = roundUp(param._PhysicalDefence * 1.1) end
					if id == 6103 then param._OilResist = 8 end
					
					param._ShakeResistRate = roundUp(param._ShakeResistRate * ((id == 6096 and 1.75) or 0.5))
					param._BlowResistRate = roundUp(param._BlowResistRate * ((id == 6096 and 1.75) or 0.5))
					param._Weight = roundUp(param._Weight * ((id == 6096 and 1.4) or 0.75))
				end
				
				if wlcArmorList[id] then -- All endgame armor now have equal prices
					param._BuyPrice = roundUp(((categorySub == "Head" and 44900) or (categorySub == "Body" and 80000) or 56700) * gearBuyMult)
					param._SellPrice = roundUp(((categorySub == "Head" and 14970) or (categorySub == "Body" and 26670) or 18900) * gearSellMult)
				end
			end
			
			if markUpgradableMisc and (categorySub == "Cloak" or categorySub == "Face") then
				if id == 3315 or id == 3350 then -- Legend's Mantle gets similar resistances to DDDA's Tattered Mantle - Wyrmhunter's Cloak is like Legend's Mantle, but with halved stats
					local defVal = (id == 3315 and 2) or 1
				
					param._PhysicalDefence = defVal
					param._MagicDefence = defVal
					param._ShakeResistRate = defVal
					param._BlowResistRate = defVal
					
					for _, res in pairs(resParams) do param[res] = 0 end
				elseif config.MODIFY_RESISTANCES then -- If enabled, cloaks will get new resistances on the categories they're lacking on
					local physDefBase = roundUp(resPhys / 5)
					local elementDefBase = roundUp(resElement / 5)
					local statusResBase = roundUp(resStatus / 5)
					local assignBase = {slashDef = physDefBase, strikeDef = physDefBase, fireDef = elementDefBase, iceDef = elementDefBase, thunderDef = elementDefBase, lightDef = elementDefBase}
					local hasPhysRes = false	
					local hasElementRes = false
					local hasStatusRes = false
					local resistances = {}
					
					for type, res in pairs(resParams) do
						if physCategory[type] then hasPhysRes = hasPhysRes or param[res] ~= 0 end
						if elementCategory[type] then hasElementRes = hasElementRes or param[res] ~= 0 end
						if statusCategory[type] then hasStatusRes = hasStatusRes or param[res] ~= 0 end
						
						param[res] = getNewResVal(param[res], assignBase[type] or statusResBase)
					end
					
					for i = 1, 3 do
						local chosenResCategory = {}
						local resList = {}
						
						if i == 1 and not hasPhysRes then chosenResCategory = physCategory
						elseif i == 2 and not hasElementRes then chosenResCategory = elementCategory
						elseif i == 3 and not hasStatusRes then chosenResCategory = statusCategory
						end
						
						for type in pairs(chosenResCategory) do 
							if resParams[type] then table.insert(resList, type) end
						end
						
						if #resList > 0 then
							local chosenRes = resList[math.random(#resList)]
							
							param[resParams[chosenRes]] = assignBase[chosenRes] or statusResBase
						end
					end
				end
			elseif config.MODIFY_RINGS and categorySub == "Ring" then -- Ring effects have been readjusted, based on their equivalent augments
				local abilityParams = CharacterManager["<HumanParam>k__BackingField"].AbilityParam.JobAbilityParameters
				local special = param._Special
				
				if special >= 1 and special <= 3 then
					local augment = abilityParams[(3 - special) * 2].Abilities[special - 1].Value / (((id == 3501 or id == 3503 or id == 3505) and 2) or 1)
					local lowestVal = (special == 1 and ((id == 3501 and 100) or 200)) or (special == 2 and ((id == 3503 and 90) or 150)) or ((id == 3505 and 5) or 10)
					
					param._SpecialValue = roundUp((augment > lowestVal and augment) or lowestVal)
				elseif special == 4 then
					param._SpecialValue = roundUp((abilityParams[4].Abilities[0].Value / 2 > 100 and abilityParams[4].Abilities[0].Value / 2) or 100)
					param._SpecialValue2 = roundUp((abilityParams[2].Abilities[1].Value / 2 > 100 and abilityParams[2].Abilities[1].Value / 2) or 100)
					param._SpecialValue3 = roundUp((abilityParams[0].Abilities[2].Value / 2 > 5 and abilityParams[0].Abilities[2].Value / 2) or 5)
				elseif (special >= 7 and special <= 9) or special == 16 or special == 26 then 
					param._SpecialValue = (special < 9 and 100) or (special == 9 and 75) or (special == 16 and 30) or 75
					param._SpecialValue2 = (special <= 9 and 0) or (special == 16 and 2) or 30
				elseif special == 21 or special == 27 or special == 30 then
					local augment = (abilityParams[(special < 30 and 2) or 8].Abilities[(special ~= 27 and 4) or 1].Value - ((special == 30 and 1) or 0)) * ((special ~= 27 and 100) or 1)
				
					param._SpecialValue = roundUp((augment > 10 and augment) or 10)
				elseif special == 5 or special == 6 or id == 3509 or id == 3511 or id == 3553 then
					local paramInd = (id == 3509 and 0) or ((id == 3511 or id == 3553) and 2) or (special == 5 and 3) or 5
					local abilityInd = (id == 3509 and 1) or ((id == 3511 or id == 3553) and 0) or 4
					local augment = abilityParams[paramInd].Abilities[abilityInd].Value
					local augment2 = abilityParams[paramInd].Abilities[abilityInd].Value2
					local finalVal =  augment / 2 + math.max(0, augment2 * 1.75)
					
					if id == 3509 then param._PhysicalDefence = roundUp((finalVal > 50 and finalVal) or 50)
					elseif id == 3511 or id == 3553 then 
						param._MagicDefence = roundUp(((finalVal > 50 and finalVal) or 50) / ((id == 3553 and 2) or 1))

						if id == 3553 then
							param._FireDefence = 10
							param._IceDefence = 10
							param._ThunderDefence = 10
							param._LightDefence = 10
							param._FireResist = 20
							param._IceResist = 20
							param._FaintResist = 20
							param._SilentResist = -40
						end
					else param._SpecialValue = roundUp((finalVal > 30 and finalVal) or 30)
					end
				elseif id == 8600 then
					local augmentDef = abilityParams[0].Abilities[1].Value / 2
					local augmentDef2 = abilityParams[0].Abilities[1].Value2 * 0.35
					local finalDef = augmentDef + math.max(0, augmentDef2)
					local augmentMdf = abilityParams[2].Abilities[0].Value / 2
					local augmentMdf2 = abilityParams[2].Abilities[0].Value2 * 0.35
					local finalMdf = augmentMdf + math.max(0, augmentMdf2)
					
					param._PhysicalDefence = math.max(10, roundUp(finalDef))
					param._MagicDefence = math.max(10, roundUp(finalMdf))
				end
				
				if markUpgradableMisc then -- If misc gear are given enhance data, then rings that give immunity to debilitations only give 80% resistance
					if id == 3518 then param._PoisonResist = 80
					elseif id == 3520 then param._SleepResist = 80
					elseif id == 3521 then param._WaterResist = 80
					elseif id == 3522 then param._OilResist = 80
					elseif id == 3524 then param._SilentResist = 80
					elseif id == 3526 then param._StoneResist = 80
					elseif id == 3527 then param._FireResist = 80
					elseif id == 3528 then param._IceResist = 80
					end
					
					-- With his permission, I used Nick's code on Weaponlord that handles the descriptions
					local ringWord = {
						[3518] = "blighted", 
						[3520] = "sleep", 
						[3521] = "drenched", 
						[3522] = "tarred", 
						[3524] = "silence", 
						[3526] = "petrification", 
						[3527] = "caught fire", 
						[3528] = "ice-bound", 
						[3530] = "experience", 
						[3531] = "discipline"
					}
					
					local resRingText = "A ring that dispels malign\npowers. Greatly reduces\naccumulation of the wearer's\n%s value."
					local boostRingText = "A ring bearing a mysterious\npower that invigorates the\nspirit. Boosts %s gained\nfrom defeating foes."					
					local description = {}
					
					for id, word in pairs(ringWord) do description[id] = string.format(((id >= 3530 and boostRingText) or resRingText), word) end
					
					sdk.hook(
						sdk.find_type_definition('app.GUIBase.ItemWindowRef'):get_method('setup(app.ItemCommonParam, System.Int32, System.Boolean)'),
						function(args)
							local storage = thread.get_hook_storage()
							
							storage.this = nil
							storage.description = nil
							
							local data = sdk.to_managed_object(args[3])
							local id = data and data._Id
							
							if not id then return end
							
							local newDesc = description[id]
							
							if not newDesc then return end
							
							local this = sdk.to_managed_object(args[2])
							
							storage.this = this
							storage.description = newDesc
						end,
						function(retval)
							local this = thread.get_hook_storage().this
							local newDesc =  thread.get_hook_storage().description
							
							if not this or not this._TxtInfo then return retval end
							
							this._TxtInfo:set_Message(newDesc)
							
							return retval
						end
					)
				end
			end
		end
	end
end

local function generateEquipmentData(equipDict)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value
		local name = param:get_Name()
		local category = itemCategory[param._Category]

		if category == "Equip" and vanillaGear[id] == true and name ~= "Invalid" then
			local job = ((id == 48303 or id == 57042 or id == 59375) and 128) or param._Job -- Fixes the job IDs of a few weapons from Ridog8's Weapon Pack
			local categorySub = equipCategory[param._EquipCategory]
			local categoryGroup = categorySub
			local buyPrice = roundUp(param._BuyPrice / gearBuyMult)
			local sellPrice = roundUp(param._SellPrice / gearSellMult)
			local priceFactor = (categorySub == "Ring" and 4) or ((categorySub == "Cloak" or categorySub == "Face") and 2.5) or 3			
			local value = (buyPrice ~= roundUp(sellPrice * priceFactor) and roundUp(sellPrice * priceFactor)) or buyPrice
			local lv = param._Lv
			
			if categorySub == "Shield" then categoryGroup = "Weapon"
			elseif categorySub == "Head" or categorySub == "Body" or categorySub == "Legs" then categoryGroup = "Armor"
			elseif categorySub == "Cloak" or categorySub == "Face" then categoryGroup = "Misc"
			end
			
			local equipData = (categoryGroup == "Weapon" and weaponData) or (categoryGroup == "Armor" and armorData) or (categoryGroup == "Misc" and miscData) or (categoryGroup == "Ring" and ringData)
			local currItem = {}
			
			param._Job = job -- Assigns the new job IDs to the weapons mentioned above
			currItem.name = name
			currItem.category = categorySub
			currItem.categoryGroup = categoryGroup
			currItem.weight = param._Weight
			currItem.buyPrice = param._BuyPrice
			currItem.sellPrice = param._SellPrice
			currItem.lv = lv
			currItem.tier = (lv < lvT2 and "T1") or (lv < lvT3 and "T2") or "T3"
			currItem.value = value
			
			if categoryGroup == "Weapon" then
				local elementPwr = param._ElementStore
				local strikePwr = param._StrikeStore
				local poisonPwr = param._PoisonStore
				local sleepPwr = param._SleepStore
				local silencePwr = param._SilentStore
				local petrifyPwr = param._StoneStore
				local wetPwr = param._WaterStore
				local tarPwr = param._OilStore
				
				currItem.str = param._PhysicalAttack
				currItem.mag = param._MagicAttack
				currItem.kdp = param._Blow
				currItem.kdg = param._BlowGuard
				currItem.staReduce = param._StaminaReduce
				currItem.elementType = elementType[param._Element]
				currItem.elementPwr = elementPwr
				currItem.strikePwr = strikePwr
				currItem.poisonPwr = poisonPwr
				currItem.sleepPwr = sleepPwr
				currItem.silencePwr = silencePwr
				currItem.petrifyPwr = petrifyPwr
				currItem.wetPwr = wetPwr
				currItem.tarPwr = tarPwr
				currItem.markElemental = elementPwr > 0
				currItem.markBlunt = strikePwr > 0 and categorySub ~= "Shield"
				currItem.markStatus = poisonPwr > 0 or sleepPwr > 0 or silencePwr > 0 or petrifyPwr > 0 or wetPwr > 0 or tarPwr > 0
				currItem.job = vocationList[job]
			else
				currItem.def = param._PhysicalDefence
				currItem.mdf = param._MagicDefence
				currItem.kdr = param._BlowResistRate
				currItem.slashDef = param._SlashDefenceRate
				currItem.strikeDef = param._StrikeDefenceRate
				currItem.fireDef = param._FireDefence
				currItem.iceDef = param._IceDefence
				currItem.thunderDef = param._ThunderDefence
				currItem.lightDef = param._LightDefence
				currItem.burnRes = param._FireResist
				currItem.freezeRes = param._IceResist
				currItem.poisonRes = param._PoisonResist
				currItem.sleepRes = param._SleepResist
				currItem.silenceRes = param._SilentResist
				currItem.petrifyRes = param._StoneResist
				currItem.wetRes = param._WaterResist
				currItem.tarRes = param._OilResist
				currItem.faintRes = param._FaintResist
				currItem.specialType = param._Special
				currItem.specialVal1 = param._SpecialValue
				currItem.specialVal2 = param._SpecialValue2
				currItem.specialVal3 = param._SpecialValue3
			end
			
			if categoryGroup == "Armor" then
				local jobCount = 0
				local compatibleJobs = {}
				local starterCompatible = false
				
				for count = 1, 9 do
					local currInd = 2 ^ (10 - count)
					
					if currInd >= 2 and currInd <= job and job - currInd >= 0 then
						jobCount = jobCount + 1
						job = job - currInd
						compatibleJobs[currInd] = vocationList[currInd]
						starterCompatible = starterCompatible or checkStarter(compatibleJobs[currInd])
					end
				end
				
				currItem.jobCount = jobCount
				currItem.compatibleJobs = compatibleJobs
				currItem.starterCompatible = starterCompatible
			end
			
			if categoryGroup == "Weapon" and categorySub ~= "Shield" and not currItem.job then
				vanillaGear[id] = false
				log.error(string.format("[ESO Base-Game Compat] SKIP malformed weapon ID=%s name=%s jobFlag=%s", tostring(id), tostring(name), tostring(job)))
			else
				equipData[id] = currItem
			end
		end
	end
	
	if config.DEBUG_MODE then
		json.dump_file("ESO/Weapon Data.json", weaponData)
		json.dump_file("ESO/Armor Data.json", armorData)
		json.dump_file("ESO/Misc Data.json", miscData)
		json.dump_file("ESO/Ring Data.json", ringData)
	end
end

local function initializeStatsData()	
	for _, job in pairs(vocationListWS) do
		bestWeapons[job] = {}
		worstWeapons[job] = {}
		
		for _, stat in pairs(offensiveStats) do
			bestWeapons[job][stat] = 0
			bestWeapons[job][stat .. "Id"] = 0
			worstWeapons[job][stat] = 0
			worstWeapons[job][stat .. "Id"] = 0
		end
	end
	
	for _, style in pairs(smithingStyleNWF) do
		bestWeaponStats[style] = {}
		
		for _, job in pairs(vocationListWS) do bestWeaponStats[style][job] = {} end
	end
	
	for _, type in pairs(armorType) do 
		bestArmor[type] = {}
		worstArmor[type] = {}
		
		for _, job in pairs(vocationList) do 
			bestArmor[type][job] = {}
			worstArmor[type][job] = {}
		
			for _, stat in pairs(defensiveStats) do
				bestArmor[type][job][stat] = 0
				bestArmor[type][job][stat .. "Id"] = 0
				worstArmor[type][job][stat] = 0
				worstArmor[type][job][stat .. "Id"] = 0
			end
		end
	end
	
	for _, style in pairs(smithingStyleNWF) do 
		bestArmorStats[style] = {}
		
		for _, type in pairs(armorType) do 
			bestArmorStats[style][type] = {}
			
			for _, job in pairs(vocationList) do bestArmorStats[style][type][job] = {} end
		end
	end
	
	for _, style in pairs(smithingStyleNWF) do 
		bestMiscStats[style] = {}
		
		for _, stat in pairs(defensiveStats) do bestMiscStats[style][stat] = 0 end
	end
end

local function collectBestandWorstStats()
	local jobCountLimit = (config.LIMIT_CANDIDATES and config.VOCATION_COUNT_LIMIT) or 9 -- If enabled, only armor usable by a certain number of vocations can qualify for best-in-slot

	for id, weapon in pairs(weaponData) do
		local job = (weapon.category == "Shield" and "Fighter - Shield") or weapon.job
		local best = bestWeapons[job]
		local worst = worstWeapons[job]
		
		if not best or not worst then
			vanillaGear[id] = false
			weaponData[id] = nil
			log.error(string.format("[ESO Base-Game Compat] SKIP stats for weapon ID=%s job=%s category=%s (unsupported reference category)", tostring(id), tostring(job), tostring(weapon.category)))
		else
		for _, stat in pairs(offensiveStats) do
			-- If the Include Only Endgame option is enabled, Molten Fury and Cinderspine are accepted best-in-slot for the MAG stat because Fighter and Warrior don't have any enchanted UW-exclusive weapons
			if not config.DISQUALIFY_MODDED_GEAR or (vanillaGear[id] and (not config.INCLUDE_ONLY_ENDGAME or (id == 1101 or id == 1302 or wlcWeaponsList[id]))) and (weapon[stat] > best[stat]) then
				best[stat] = weapon[stat]
				best[stat .. "Id"] = id
			end
			
			if worst[stat] == 0 or weapon[stat] < worst[stat] then
				worst[stat] = weapon[stat]
				worst[stat .. "Id"] = id
			end
		end
		end -- recognized vocation only
	end
	
	for _, style in pairs(smithingStyleNWF) do
		for _, job in pairs(vocationListWS) do			
			for _, stat in pairs(offensiveStats) do bestWeaponStats[style][job][stat] = roundUp(bestWeapons[job][stat] * ((stat == "kdg" and 1) or weaponStatMults[style][stat])) end -- KDG is the same on all smithing styles
		end
	end
	
	for id, armor in pairs(armorData) do
		local category = armor.category
		local jobCount = armor.jobCount
		local compatibleJobs = armor.compatibleJobs
		
		for _, currJob in pairs (compatibleJobs) do
			local best = bestArmor[category][currJob]
			local worst = worstArmor[category][currJob]
			
			for _, stat in pairs(defensiveStats) do
				-- Some vocations don't have exclusive best-in-slot equipment, so a vocation count limit is used to limit selection
				if jobCount <= jobCountLimit and (not config.DISQUALIFY_MODDED_GEAR or (vanillaGear[id] and (not config.INCLUDE_ONLY_ENDGAME or wlcArmorList[id]))) and (armor[stat] > best[stat]) then
					-- Mystic Spearhand's best-in-slot body armor gets a 25% nerf to its stats if it isn't exclusive to that vocation
					best[stat] = roundUp(armor[stat] * (((config.NERF_MS_BODY_ARMOR and (currJob == "Mystic Spearhand" and category == "Body" and armor.jobCount > 1)) and 0.75) or 1))
					best[stat .. "Id"] = id
				end
			
				if id ~= 7000 and id ~= 7001 and (worst[stat] == 0 or armor[stat] < worst[stat]) then -- The other Miner's Shirt and Laborer's Trousers are excluded
					worst[stat] = armor[stat]
					worst[stat .. "Id"] = id
				end
			end
		end
	end
	
	for _, style in pairs(smithingStyleNWF) do				
		for _, type in pairs(armorType) do
			for _, job in pairs(vocationList) do	
				for _, stat in pairs(defensiveStats) do bestArmorStats[style][type][job][stat] = roundUp(bestArmor[type][job][stat] * armorStatMults[style][stat]) end
			end
		end
	end
	
	local miscHighestVal = 0 
	local idBest = 0
	
	for id, misc in pairs(miscData) do
		if (not config.DISQUALIFY_MODDED_GEAR or vanillaGear[id]) and misc.value > miscHighestVal then 
			miscHighestVal = misc.value
			idBest = id
		end
	end
	
	bestMisc = {id = idBest, name = miscData[idBest].name, value = miscData[idBest].value}
	
	for _, style in pairs(smithingStyleNWF) do
		for _, type in pairs(armorType) do
			for _, job in pairs(vocationList) do
				for _, stat in pairs(defensiveStats) do bestMiscStats[style][stat] = bestMiscStats[style][stat] + (bestArmorStats[style][type][job][stat] / 9) end
			end
		end
		
		for _, stat in pairs(defensiveStats) do bestMiscStats[style][stat] = roundUp(bestMiscStats[style][stat] / 9) end
	end
	
	for id, ring in pairs(ringData) do	
		if (not config.DISQUALIFY_MODDED_GEAR or vanillaGear[id]) and (id ~= 3553 and id ~= 3555) and ring.value > bestRing then bestRing = ring.value end
	end
	
	if config.DEBUG_MODE then 
		json.dump_file("ESO/Weapon Data - Best Items.json", bestWeapons)
		json.dump_file("ESO/Weapon Data - Worst Items.json", worstWeapons)
		json.dump_file("ESO/Weapon Data - Best Stats.json", bestWeaponStats)		
		json.dump_file("ESO/Armor Data - Best Items.json", bestArmor)
		json.dump_file("ESO/Armor Data - Worst Items.json", worstArmor)
		json.dump_file("ESO/Armor Data - Best Stats.json", bestArmorStats)
		json.dump_file("ESO/Misc Data - Best Item.json", bestMisc)
		json.dump_file("ESO/Misc Data - Best Stats.json", bestMiscStats)
		json.dump_file("ESO/Ring Data - Highest Value.json", bestRing)
	end
end

local function modifyEquipmentLevels(equipDict)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")	
	
	if not config.REBALANCE_EQUIPMENT then -- The extra WLC gear are excluded if the Rebalance Equipment option is disabled
		for _, id in pairs(wlcWeaponsExtra) do wlcWeaponsList[id] = false end
		for _, id in pairs(wlcArmorExtra) do wlcArmorList[id] = false end
	end
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value
		local name = param:get_Name()
		local category = itemCategory[param._Category]

		if category == "Equip" and vanillaGear[id] == true and name ~= "Invalid" then
			local item = getDataById(id)
			local categorySub = item.category
			local categoryGroup = item.categoryGroup
			local value = item.value
			local newLv = 0
			
			if categoryGroup == "Weapon" then				
				if id == 1513 or id == 1804 or id == 2210 or wlcWeaponsList[id] then newLv = maxLv -- Level requirements of Legion's Might, Medusan Spellbow, Daughter of the Evening, and all endgame weapons are set to max level
				else
					local job = (categorySub == "Shield" and "Fighter - Shield") or item.job
					local markElemental = item.markElemental
					local markBlunt = item.markBlunt
					local markStatus = item.markStatus
					local best = bestWeapons[job]
					local worst = worstWeapons[job]
					local lvMult = 0
					
					local lvFactor = {
						str = (categorySub == "Shield" and 0.6) or (job == "Mystic Spearhand" and 0.4) or (job == "Trickster" and 0.3333) or (checkMagickPrimary(job) and 0) or 0.8,
						mag = (job == "Mystic Spearhand" and 0.4) or (job == "Trickster" and 0.6667) or (checkMagickPrimary(job) and 0.8) or 0,
						kdp = (categorySub == "Shield" and 0.2) or (job == "Trickster" and 0) or ((job == "Mage" or job == "Sorcerer") and 0.1) or 0.2,
						kdg = (categorySub == "Shield" and 0.2) or ((job == "Mage" or job == "Sorcerer") and 0.1) or 0
					}
					
					for _, stat in pairs(offensiveStats) do
						if not (markElemental and not checkMagickPrimary(job) and stat == "mag") then
							local statBase = item[stat]
							
							if statBase > 0 then							
								if markElemental then
									if checkMagickPrimary(job) and stat == "mag" then statBase = statBase * (1 + enchantRate)
									elseif stat == "str" then statBase = statBase + (item.mag * enchantRate)
									end
								end
								
								local statBiS = best[stat]
								local statWiS = worst[stat]
								local statMaxDiff = statBiS - statWiS
								local statDiff = statBiS - statBase
								
								if statDiff > 0 then lvMult = lvMult + ((statDiff / statMaxDiff) * lvFactor[stat]) end
							end
						end
					end
					
					local minLv = (checkStarter(job) and 1) or advJobLv
					local lvDiff = maxLv - minLv
					
					minLv = minLv + ((lvDiff * statAdj) * (((markElemental and 0.5) or 0) + ((markStatus and 1) or 0)))
					newLv = roundUp(minLv + (lvDiff * (1 - lvMult)))
				end
			elseif categoryGroup == "Armor" then
				if id == 10312 or id == 10409 or id == 10512 then newLv = lvT3 -- The Sovran Set is set to the minimum level for T3 equipment
				-- The Marcher Set is set to an eighth of the max level, or 30% of the max level if the Rebalance Equipment option is enabled
				elseif id == 4119 or id == 5117 or id == 6117 then newLv = roundUp((config.REBALANCE_EQUIPMENT and maxLv * 0.3) or maxLv / 8)
				elseif id == 5138 or id == 6124 then newLv = roundUp(maxLv / 10) -- The Courtly Set is set to a tenth of the max level				
				elseif id == 4120 or id == 5119 or id == 6119 then newLv = roundUp(maxLv * 0.55) -- The Forbidden Magick Research Lab Uniform is set to the 55% of the max level				
				elseif wlcArmorList[id] then newLv = maxLv -- Level requirements of all endgame armor are fixed at max level
				else
					local lvMult = 0
					
					for _, currJob in pairs(item.compatibleJobs) do					
						local lvFactor = {
							def = (currJob == "Mystic Spearhand" and 0.4) or (checkMagickPrimary(currJob) and 0.2) or 0.6,
							mdf = (currJob == "Mystic Spearhand" and 0.4) or (checkMagickPrimary(currJob) and 0.6) or 0.2,
							kdr = 0.2
						}
						
						for _, stat in pairs(defensiveStats) do
							local statBase = item[stat]
							
							if statBase > 0 then
								local statBiS = bestArmor[categorySub][currJob][stat]
								local statWiS = worstArmor[categorySub][currJob][stat]
								local statMaxDiff = statBiS - statWiS
								local statDiff = statBiS - statBase
							
								if statDiff > 0 then lvMult = lvMult + ((statDiff / statMaxDiff) * lvFactor[stat]) end
							end
						end
					end
					
					-- Charming Corset's level is decreased by 20% if the Rebalance Equipment option is enabled
					newLv = roundUp((1 + (maxLv - 1) * (1 - lvMult / item.jobCount)) * (((id == 5116 and config.REBALANCE_EQUIPMENT) and 0.8) or 1)) 
				end
			-- The Eventide and Salamander Masks are set to a tenth of the max level, while Wyrmhunter's Cloak 's equipment level is 10% higher, if the Rebalance Equipment option is enabled
			elseif categoryGroup == "Misc" then	newLv = roundUp(((id == 3400 or id == 3401) and maxLv / 10) or (maxLv * (value / bestMisc.value) * (((id == 3350 and config.REBALANCE_EQUIPMENT) and 1.1) or 1)))
			else newLv = (value >= bestRing * (lvT3 / maxLv) and lvT3) or (value >= bestRing * (lvT2 / maxLv) and lvT2) or 1
			end
			
			param._Lv = math.min(maxLv, math.max(1, newLv))
			
			local equipLevels = (categoryGroup == "Weapon" and weaponLevels) or (categoryGroup == "Armor" and armorLevels) or (categoryGroup == "Misc" and miscLevels) or ringLevels
			
			equipLevels[id] = {}
			equipLevels[id].name = name
			equipLevels[id].lv = param._Lv
			
			if categoryGroup == "Weapon" or categoryGroup == "Armor" then equipLevels[id].job = (categoryGroup == "Weapon" and vocationList[param._Job]) or param._Job end
			if categoryGroup ~= "Ring" then equipLevels[id].category = categorySub end
		end
	end
	
	generateEquipmentData(equipDict) -- This needs to be run again to record the new equipment levels
	
	if config.DEBUG_MODE then
		json.dump_file("ESO/Weapon Data - Levels.json", weaponLevels)
		json.dump_file("ESO/Armor Data - Levels.json", armorLevels)
		json.dump_file("ESO/Misc Data - Levels.json", miscLevels)
		json.dump_file("ESO/Ring Data - Levels.json", ringLevels)
	end
end

local function alterUnselectedBestGear(equipDict)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value
		local name = param:get_Name()
		local category = itemCategory[param._Category]
		
		if category == "Equip" and vanillaGear[id] == true and name ~= "Invalid" then
			local item = getDataById(id)
			local categoryGroup = item.categoryGroup
			
			if categoryGroup == "Weapon" or categoryGroup == "Armor" then
				if not (config.EXCLUDE_VANILLA_GEAR and vanillaGear[id]) then
					local nerf = item.lv / maxLv
					local markStronger = false
					
					if categoryGroup == "Weapon" then
						local job = (item.category == "Shield" and "Fighter - Shield") or item.job
						local best = bestWeapons[job]
						
						for _, stat in pairs(offensiveStats) do markStronger = markStronger or (item[stat] > best[stat] and id ~= best[stat .. "Id"]) end
						
						if markStronger then
							for _, statParam in pairs({"_PhysicalAttack", "_MagicAttack", "_Shake", "_Blow", "_ShakeGuard", "_BlowGuard"}) do param[statParam] = param[statParam] * nerf end
						end
					else
						for _, stat in pairs(defensiveStats) do
							local statBest = 0
							local markBiS = false
							
							for _, currJob in pairs(item.compatibleJobs) do
								local best = bestArmor[item.category][currJob]
								
								statBest = statBest + ((best[stat] / item.jobCount) * ((id == 5116 and 1.2) or 1)) -- Charming Corset takes up 2 armor slots, so best stats are 20% higher
								markBiS = markBiS or (id == best[stat .. "Id"])
							end
							
							markStronger = markStronger or (item[stat] > statBest and not markBiS)
						end
						
						if markStronger then
							for _, statParam in pairs({"_PhysicalDefence", "_MagicDefence", "_ShakeResistRate", "_BlowResistRate"}) do param[statParam] = param[statParam] * nerf end
						end
					end
				end
			end
		end
	end
	
	generateEquipmentData(equipDict) -- This needs to be run again to record the new stats
end

local function buildEnhanceDataLookup(equipDict)
    local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
    local hasEnhanceData = {}

    while enum:MoveNext() do hasEnhanceData[enum:get_Current().key] = true end

    return hasEnhanceData
end

local function createEnhanceDataTemplate(type)
    local paramType = "app." .. type .. "EnhanceParam"
    local array = sdk.create_managed_array(paramType, 13)

    for i = 0, 12 do array[i] = sdk.create_instance(paramType):add_ref() end

    return array
end

local function populateEnhanceData(equipData, equipDict, checkExist, recentList, type)
    for id in pairs(equipData) do
        if not checkExist[id] then
            recentList[id] = true
            equipDict[id] = createEnhanceDataTemplate(type)
        end
    end
end

local function generateEnhanceParams(equipDict, equipNowUpgradable, itemType)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local paramsArray = enum:get_Current().value
		
		if equipNowUpgradable[id] then
			for i = 0, paramsArray:get_Length() - 1 do
				local param = paramsArray[i]
				
				param._EnhanceNo = i % 3
				param._Type = math.min(i // 3, 4)
				param._WeightRate = (i == 12 and 50) or 100
			end
		end
	end
	
	if config.DEBUG_MODE then json.dump_file("ESO/" .. itemType .. " Data - Now Upgradable.json", equipNowUpgradable) end
end

local function createEnhanceData(weaponDict, armorDict)
	local weaponHasEnhanceData = buildEnhanceDataLookup(weaponDict)
	local armorHasEnhanceData = buildEnhanceDataLookup(armorDict)
	
	populateEnhanceData(weaponData, weaponDict, weaponHasEnhanceData, weaponNowUpgradable, "Weapon")
    populateEnhanceData(armorData, armorDict, armorHasEnhanceData, armorNowUpgradable, "Armor")

	if next(weaponNowUpgradable) then generateEnhanceParams(weaponDict, weaponNowUpgradable, "Weapon") end
	if next(armorNowUpgradable) then generateEnhanceParams(armorDict, armorNowUpgradable, "Armor") end	
	
	if markUpgradableMisc then
		populateEnhanceData(miscData, armorDict, armorHasEnhanceData, miscNowUpgradable, "Armor")
		
		if next(miscNowUpgradable) then generateEnhanceParams(armorDict, miscNowUpgradable, "Misc") end
	end
end

local function computeGainPerLvAndEnhancePriceRate(markWeapon)
	local enhancePrice = 0.05
	local enhancePriceMult = {1, 2.4, (markWeapon and 6) or 5}
	local enhancePriceMultTotal = (markWeapon and 9.4) or 8.4
	local enhancePriceRate = {}
	local gainPerLv = {}
	
	for ind, mult in pairs(enhancePriceMult) do
		enhancePriceRate[ind] = enhancePrice * mult
		gainPerLv[ind] = mult / enhancePriceMultTotal
	end
	
	return gainPerLv, enhancePriceRate
end

local function unequalizeFinalStats(id, statBest)
	local item = getDataById(id)
	local categoryGroup = item.categoryGroup
	local minLv = ((categoryGroup ~= "Weapon" or checkStarter(item.job)) and 1) or advJobLv
	local lv = item.lv
	local statGap = maxGap * (1 - ((lv - minLv) / (maxLv - minLv)))
	
	if categoryGroup == "Armor" then
		statGap = 0
		
		for _, currJob in pairs(item.compatibleJobs) do	
			minLv = (checkStarter(currJob) and 1) or advJobLv
			statGap = statGap + ((maxGap * (1 - ((lv - minLv) / (maxLv - minLv)))) / item.jobCount)
		end
	end
		
	return statBest * (1 - math.max(0, statGap))
end

local function computeFinalStat(id, smithStyle, upgradeLv, gainPerLv, stat, job)
	local item = getDataById(id)
	local categoryGroup = item.categoryGroup
	local markWeapon = categoryGroup == "Weapon"
	local markArmor = categoryGroup == "Armor"
	local markMisc = categoryGroup == "Misc"
	local markBasic = (config.USE_BASIC_STAT_COMPUTATION and (not markArmor or not config.EXCLUDE_ARMOR)) or (Weaponlord_installed and id == 1208)
	local currStatMult = ((markWeapon and weaponStatMults) or armorStatMults)[smithStyle][stat]
	local statBase = item[stat]
	local statBest = (markBasic and (statBase * (((markWeapon and stat == "kdg") and 1) or currStatMult))) or 0
	
	if not markBasic then
		if markWeapon and statBase > 0 then statBest = bestWeaponStats[smithStyle][job][stat]
		elseif markMisc then statBest = bestMiscStats[smithStyle][stat]
		elseif markArmor then
			for _, currJob in pairs(item.compatibleJobs) do statBest = statBest + (bestArmorStats[smithStyle][item.category][currJob][stat] / item.jobCount) end
		end
		
		if config.UNEQUALIZE_FINAL_STATS and statBest > 0 then statBest = unequalizeFinalStats(id, statBest) end
	end
	
	if markWeapon then
		if config.ADJUST_SPECIAL_WEAPONS then
			if item.markElemental and ((not checkMagickPrimary(item.job) and stat == "str") or stat == "kdp") then statBest = statBest * (1 - (statAdj / ((not checkMagickPrimary(item.job) and 2) or 1))) end
			
			if item.markBlunt and (stat == "str" or stat == "kdp") then
				-- Dragon's Flight has strike power but it isn't a hammer; it's a battleaxe so it now deals 80% slash, 20% blunt, getting a fifth of the adjustments for maces and hammers
				-- War Blade becomes half blunt, so it gets only half the adjustments for maces and hammers
				local bluntStatAdj = statAdj / ((id == 1303 and 5) or (id == 1202 and 2) or 1)
				
				statBest = statBest * ((stat == "str" and 1 - bluntStatAdj) or (1 + bluntStatAdj))
			end
			
			if item.markStatus and stat == "kdp" then statBest = statBest * (1 - statAdj) end
		end
		
		if config.REBALANCE_EQUIPMENT then
			-- Carnation gets a 5% nerf to its final KDP, because of its increased Slash Strength
			-- Dragon's Flight gets a 10% nerf to its final STR and a 5% nerf to its final KDP
			-- Cyclopean Thunder now has higher overall power to inflict the Unconscious debilitation, so its final STR and MAG get nerfed by 10%
			-- Legion's Might gets a 10% nerf to its final MAG, KDP, and KDG due to its auto-revive ability
			local wpnStatAdj = statAdj / (((id == 1009 or (id == 1303 and stat == "kdp")) and 2) or 1)
			
			if (stat == "str" and (id == 1206 or id == 1303)) or (stat == "mag" and id == 1206) or (stat == "kdp" and (id == 1009 or id == 1303)) or (stat ~= "str" and id == 1513) then statBest = statBest * (1 - wpnStatAdj) end
		end
	end
	
	local statIncTotal = (statBest * (((not markBasic and id == 5116) and 1.2) or 1)) - statBase -- If Basic Stat Computation is disabled, Charming Corset takes up 2 slots, so best stat value is increased by 20%
	local statIncFinal = statIncTotal * gainPerLv[upgradeLv]
	
	if upgradeLv == 3 then 
		local statInc = {}
		
		for i = 1, upgradeLv do statInc[i] = (i == 3 and statIncTotal - (statInc[1] + statInc[2])) or (statIncTotal * gainPerLv[i]) end
		
		statIncFinal = statInc[3]
	end
	
	return roundUp(statIncFinal / ((item.category == "Face" and 2) or 1))
end

local function prepareStatBoostData(boostMult, type)
	local statBoost = {}
	
	if type == "Misc" then
		for _, stat in pairs(defensiveStats) do
			if stat ~= "kdr" then 
				statBoost[stat] = 0
				
				for _, style in pairs(smithingStyleNWF) do statBoost[stat] = statBoost[stat] + ((bestMiscStats[style][stat] / 4) * boostMult) end
			end
		end
	elseif type == "Weapon" then	
		for _, job in pairs(vocationListWS) do
			statBoost[job] = {}
			
			for _, stat in pairs(offensiveStats) do
				if stat ~= "kdp" then 
					statBoost[job][stat] = 0
					
					for _, style in pairs(smithingStyleNWF) do statBoost[job][stat] = statBoost[job][stat] + ((bestWeaponStats[style][job][stat] / 4) / 7.5 * boostMult) end
				end
			end
		end
	else
		for _, job in pairs(vocationList) do
			statBoost[job] = {}
			
			for _, type in pairs(armorType) do
				statBoost[job][type] = {}
				
				for _, stat in pairs(defensiveStats) do
					if stat ~= "kdr" then
						statBoost[job][type][stat] = 0
						
						for _, style in pairs(smithingStyleNWF) do statBoost[job][type][stat] = statBoost[job][type][stat] + ((bestArmorStats[style][type][job][stat] / 40) * boostMult) end
					end
				end
			end
		end
	end
	
	return statBoost
end

local function computeEffectBonuses(id, smithStyle, currGainPerLv)
	local item = weaponData[id]
	local effectList = {}
	local effects = {}
	
	for type in pairs(effectParams) do effectList[type] = item[type] end
	
	for type, effect in pairs(effectList) do
		if effect > 0 then
			local effectCategory = (physCategory[type] and "Phys") or (elementCategory[type] and "Element") or (statusCategory[type] and "Status")
			local effectAdj = (smithStyle == "Wyrmfire" and wyrmfireStatBonus * 2) or secondaryStatMults[smithStyle][effectCategory]
			
			effects[type] = roundUp((effect * effectAdj) * currGainPerLv)
		end
	end
	
	return effects
end

local function computeResistanceBonuses(id, smithStyle, upgradeLv, gainPerLv)
	local item = getDataById(id)
	local markMisc = item.categoryGroup == "Misc"
	local resMult = ((item.category == "Cloak" and 2) or 1)
	local checkBypass = (id == 3315 or id == 3350) or smithStyle == "Wyrmfire"
	local resList = {}
	local resistances = {}
	
	for type in pairs(resParams) do resList[type] = item[type] end
	
	for type, res in pairs(resList) do
		if res ~= 0 or checkBypass then
			local resCategory = (physCategory[type] and "Phys") or (elementCategory[type] and "Element") or (statusCategory[type] and "Status")
			local resStatusType = resCategory == "Status" or type == "faint" or type == "burn" or type == "freeze"			
			local resVal = (((resCategory == "Status" or type == "faintRes" or type == "burnRes" or type == "freezeRes") and resStatus) or (resCategory == "Phys" and resPhys) or resElement) * resMult
			
			res = ((markMisc or checkBypass) and resVal) or res -- If the item's misc gear or smithing style is Wyrmfire, then the original resistance value is replaced
			
			if smithStyle ~= "Wyrmfire" then
				-- If resistance is negative, the upgrades will reduce the penalty
				local resIncTotal = roundUp((res / ((id == 3315 and 2) or (id == 3350 and 3) or 1)) * (secondaryStatMults[smithStyle][resCategory] * ((res < 0 and -1) or 1))) - ((markMisc and item[type]) or 0)
				local resIncFinal = resIncTotal * gainPerLv[upgradeLv]
				
				if upgradeLv == 3 then 
					local resInc = {}
					
					for i = 1, upgradeLv do resInc[i] = (i == 3 and resIncTotal - (resInc[1] + resInc[2])) or (resIncTotal * gainPerLv[i]) end
					
					resIncFinal = resInc[3]
				end
			
				resistances[type] = roundUp(resIncFinal)
			else resistances[type] = roundUp(res * (((markMisc or checkBypass) and 0.2) or (item.category ~= "Body" and 0.5) or 1))
			end
		end
	end
	
	return resistances
end

local function computeWeight(weight, smithStyle, currGainPerLv)	
	return roundUp((weight * 0.075) * (currGainPerLv * (((smithStyle == "Elven" or smithStyle == "Dwarven") and 2) or 1) * (((smithStyle == "Vermundian" or smithStyle == "Elven") and -1) or 1)))
end

local function computeUpgradeCost(id, upgradeLv, gainPerLv, enhancePriceRate)
	local item = getDataById(id)
	local category = item.category
	local categoryGroup = item.categoryGroup
	local markWeapon = categoryGroup == "Weapon"
	local markArmor = categoryGroup == "Armor"
	local markMisc = categoryGroup == "Misc"
	
	local goldMax = {
		Weapon = config.HIGH_VAL_WEAPON, Shield = config.HIGH_VAL_SHIELD, 
		Head = config.HIGH_VAL_HEAD, Body = config.HIGH_VAL_BODY, Legs = config.HIGH_VAL_LEGS, 
		Cloak = config.HIGH_VAL_MISC, Face = roundUp(config.HIGH_VAL_MISC / 2)
	}
	
	if not config.USE_CUSTOM_HIGHEST_VALUES and not markMisc then -- Misc gear always use the highest value variables
		local highVal = goldMax[category]
		local bestGear = (markWeapon and bestWeapons) or bestArmor
		local stats = (markWeapon and offensiveStats) or defensiveStats
		local equipData = getEquipData(categoryGroup)
		local statCount = 0
		
		for job in pairs(bestGear) do
			for _, stat in pairs(stats) do
				if stat ~= "kdp" and stat ~= "kdr" then
					local gearBiS = (markWeapon and bestGear[job][stat .. "Id"]) or bestGear[job][category][stat .. "Id"]
					
					if gearBiS > 0 then
						highVal = highVal + equipData[gearBiS].value
						statCount = statCount + 1
					end
				end
			end
		end
		
		goldMax[category] = roundUp(highVal / statCount)
	end

	local lv = item.lv
	local minLv = ((not markWeapon or checkStarter(item.job)) and 1) or advJobLv
	local goldCost = (item.value / gearBuyMult) * enhancePriceRate[upgradeLv]
	local gainPerLvAcc = 0
	local goldMult = 0
	
	for i = 1, upgradeLv do gainPerLvAcc = gainPerLvAcc + gainPerLv[i] end
	
	if markArmor then 		
		for _, currJob in pairs(item.compatibleJobs) do
			minLv = (checkStarter(currJob) and 1) or advJobLv
			goldMult = goldMult + (((1 - (maxGap * (1 - ((lv - minLv) / (maxLv - minLv))))) / item.jobCount) * gainPerLvAcc)
		end
	else goldMult = ((1 - (maxGap * (1 - ((lv - minLv) / (maxLv - minLv))))) * gainPerLvAcc) * ((id == 2210 and 1.25) or 1) -- Daughter of the Evening's upgrade costs are 25% more expensive
	end
	
	return roundUp((((goldMax[category] * enhancePriceRate[upgradeLv]) - goldCost) * goldMult) + goldCost)
end

local function modifyWeaponEnhanceData(weaponDict)
	local enum = weaponDict:call("System.Collections.IEnumerable.GetEnumerator()")
	local gainPerLv, enhancePriceRate = computeGainPerLvAndEnhancePriceRate(true)
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local paramsArray = enum:get_Current().value
		local item = weaponData[id]
		
		if item then 
			for i = 0, paramsArray:get_Length() - 1 do
				local param = paramsArray[i]
				local upgradeLv = param._EnhanceNo + 1
				local smithStyle = smithingStyle[param._Type]
				local category = item.category
				local job = (category == "Shield" and "Fighter - Shield") or item.job
				local currGain = gainPerLv[upgradeLv]
				
				if smithStyle == "Wyrmfire" then
					local statBoost = prepareStatBoostData((config.BOOST_WYRMFIRE_UPGRADES and (1 + wyrmfireStatBonus)) or 1, "Weapon")
					
					for _, stat in pairs(offensiveStats) do
						if stat ~= "kdp" and item[stat] > 0 then
							local statBoostMult = ((item.markElemental and not checkMagickPrimary(job)) and ((stat == "str" and 1.4) or 2.2)) or 1
							local currStatBoost = statBoost[job][stat]
							
							if stat == "str" then param._PhysicalAttack = roundUp(currStatBoost / statBoostMult)
							elseif stat == "mag" then param._MagicAttack = roundUp(currStatBoost * statBoostMult)
							elseif category == "Shield" or job == "Mage" or job == "Sorcerer" then
								param._ShakeGuard = roundUp(currStatBoost)
								param._BlowGuard = roundUp(currStatBoost)
							end
						end
					end
						
					if config.BOOST_WYRMFIRE_UPGRADES then
						local effects = computeEffectBonuses(id, smithStyle, 1)
						
						if effects then
							for type, effect in pairs(effects) do
								if effect > 0 then param[effectParams[type]] = effect end
							end
						end
						
						-- There's a stamina reduction paramter but when I applied it to all weapons, it didn't seem to do anything
						-- Lustrous Targe and Dread Aspis have this so maybe it only affects stamina used when blocking
						-- Mages and sorcerers can now use Magick Barrier, so they're probably gonna benefit from this as well
						param._StaminaReduce = item.staReduce + 5
						-- COMPAT: retain vanilla smithing gold costs while keeping ESO's stat gains.
						if not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = roundUp(param._NeedMoney * (1 + (wyrmfireStatBonus * 2))) end
					end
					
					if config.HALVE_WEIGHT_REDUCTION then 
						param._WeightRate = 75
						if not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = roundUp(param._NeedMoney * 0.7) end
					end
				else
					for _, stat in pairs(offensiveStats) do
						local statFinal = math.max(0, computeFinalStat(id, smithStyle, upgradeLv, gainPerLv, stat, job))
						
						if statFinal ~= 0 then
							if stat == "str" then param._PhysicalAttack = roundUp(statFinal)
							elseif stat == "mag" then param._MagicAttack = roundUp(statFinal)
							elseif stat == "kdp" then 
								param._Shake = roundUp(statFinal)
								param._Blow = roundUp(statFinal)
							else
								param._ShakeGuard = roundUp(statFinal)
								param._BlowGuard = roundUp(statFinal)
							end
						end
					end
					
					local goldFinal = (markRecalculateCosts and computeUpgradeCost(id, upgradeLv, gainPerLv, enhancePriceRate)) or item.value * enhancePriceRate[upgradeLv]
					
					param._Weight = computeWeight(item.weight, smithStyle, currGain)
					if not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = roundUp(goldFinal * enhanceGoldMult) end
					
					if config.AGGRANDIZE_SMITHING_STYLES then
						local effects = computeEffectBonuses(id, smithStyle, currGain)
						
						if effects then
							for type, effect in pairs(effects) do
								if effect > 0 then param[effectParams[type]] = effect end
							end
						end
					end
				end
			end
		end
	end
end

local function modifyArmorEnhanceData(armorDict, type)
	local enum = armorDict:call("System.Collections.IEnumerable.GetEnumerator()")
	local gainPerLv, enhancePriceRate = computeGainPerLvAndEnhancePriceRate()
	local markMisc = type == "Misc"

	while enum:MoveNext() do
		local id = enum:get_Current().key
		local paramsArray = enum:get_Current().value
		local item = getDataById(id)
		
		if item and item.categoryGroup == type then
			for i = 0, paramsArray:get_Length() - 1 do
				local param = paramsArray[i]
				local upgradeLv = param._EnhanceNo + 1
				local smithStyle = smithingStyle[param._Type]
				local category = item.category

				if smithStyle == "Wyrmfire" then
					local statBoost = prepareStatBoostData((config.BOOST_WYRMFIRE_UPGRADES and (1 + wyrmfireStatBonus)) or 1, type)
					
					for _, stat in pairs(defensiveStats) do
						if stat ~= "kdr" then
							local currStatBoost = (markMisc and (statBoost[stat] / ((category == "Cloak" and 8) or 16))) or 0

							if not markMisc then
								for _, currJob in pairs(item.compatibleJobs) do currStatBoost = currStatBoost + statBoost[currJob][category][stat] / item.jobCount end
							end

							if stat == "def" then param._PhysicalDefence = roundUp(currStatBoost)
							else param._MagicDefence = roundUp(currStatBoost)
							end
						end
					end

					if markMisc and not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = (category == "Cloak" and 10) or 5 end

					if config.BOOST_WYRMFIRE_UPGRADES then
						local resistances = computeResistanceBonuses(id, smithStyle)

						if resistances then
							for type, res in pairs(resistances) do param[resParams[type]] = res end
						end

						if not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = roundUp(param._NeedMoney * (1 + (wyrmfireStatBonus * 2))) end
					end
					
					if config.HALVE_WEIGHT_REDUCTION then 
						param._WeightRate = 75
						if not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = roundUp(param._NeedMoney * 0.7) end
					end
				else
					for _, stat in pairs(defensiveStats) do
						local statFinal = computeFinalStat(id, smithStyle, upgradeLv, gainPerLv, stat)

						if stat == "def" then param._PhysicalDefence = roundUp(statFinal)
						elseif stat == "mdf" then param._MagicDefence = roundUp(statFinal)
						else
							param._ShakeResistRate = roundUp(statFinal)
							param._BlowResistRate = roundUp(statFinal)
						end
					end

					local goldFinal = (markRecalculateCosts and computeUpgradeCost(id, upgradeLv, gainPerLv, enhancePriceRate)) or (item.value * enhancePriceRate[upgradeLv])

					param._Weight = computeWeight(item.weight, smithStyle, gainPerLv[upgradeLv])
					if not config.COMPAT_BASE_GAME_ONLY then param._NeedMoney = roundUp(goldFinal * enhanceGoldMult) end

					if config.AGGRANDIZE_SMITHING_STYLES then
						local resistances = computeResistanceBonuses(id, smithStyle, upgradeLv, gainPerLv)

						if resistances then
							for type, res in pairs(resistances) do param[resParams[type]] = res end
						end
					end
				end
			end
		end
	end
end

local function generateItemData(itemDict)
	local enum = itemDict:call("System.Collections.IEnumerable.GetEnumerator()")	
	local valHighest = {0, 0, 0}
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value		
		local name = param:get_Name()
		local category = itemCategory[param._Category]
		
		if category ~= "Equip" and name ~= "Invalid" then
			local categorySub = itemSubCategory[param._SubCategory]
			local categoryFinal = category
			local sellPrice = param._SellPrice
			
			if GPO_installed then
				categoryFinal = "Uncategorized"
				
				if category == "Use" then
					if categorySub == "Heal" then categoryFinal = "Curative"
					elseif categorySub == "Buff" or categorySub == "Special" or categorySub == "Arrow" or categorySub == "Magic Book" then categoryFinal = "Implement"
					end
				end
				
				sellPrice = roundUp(sellPrice / ((categoryFinal == "Curative" and curesSellMult) or (categoryFinal == "Material" and matsSellMult) or (categoryFinal == "Implement" and othersSellMult) or 1))
			end
			
			-- For uncategorized items, there's no change
			-- For materials, buy prices are usually 3.3333x of the sell prices
			-- For the rest, buy prices are usually 2.8571x of the sell prices
			local priceFactor = ((categoryFinal == "Other" or categoryFinal == "Uncategorized") and 1) or (categoryFinal == "Material" and 3.3333) or 2.8571 			
			local value = sellPrice * priceFactor
			
			-- Pointed Fangs are now equally valuable with Sinister Fangs, since Garms are stronger than Wargs, though Wargs are rarer to encounter
			-- Both fangs also become more valuable since they're rather scarce in the Normal World
			-- Fell-Lord's Bones are more valuable while Silver Crowns are less valuable, since Skeleton Lords are stronger than Stout Undead
			-- Misshapen Eye becomes less valuable since it can dropped by the very first boss you encounter in the game
			-- Sunstone is slightly less valuable while Southron Iron is slightly more valuable, to match the gap with the other minerals
			-- Griffins are weaker than Dragons, yet their materials are priced similarly, so now they're less valuable	
			-- Eldricite is now more valuable since Specters only spawn in the Unmoored World
			-- Astracite becomes more valuable to address the irregular value gap between the Phantasm family loot	
			-- Tiger Eye is now just as valuable as Jasper and Onyx
			-- Jasper, Onyx, and Tiger Eye are less valuable since you can get them early
			-- Magick Medal and Wyrmslife Crystal are much less valuable because you can get them in piles - Wormslife Crystal is also affected for obvious reasons
			if id == 215 or id == 238 then value = value * 1.5 end
			if id == 215 or id == 216 or id == 199 then value = value * 1.25 end			
			if id == 245 or id == 237 then value = value * 2 end
			if id == 234 or id == 251 then value = value / 2 end
			if id == 202 then value = value / 1.4 end
			if id == 261 or id == 262 then value = value * 0.75 end
			if id == 346 then value = value / 1.125 end
			if id >= 344 and id <= 346 then value = value / 2.5 end
			if id == 259 or id == 359 or id == 473 then value = value / 5 end
			
			value = roundUp(value)
			
			if category == "Material" then -- Checks for the most expensive materials				
				if value > valHighest[1] then 
					valHighest[3] = valHighest[2]
					valHighest[2] = valHighest[1]
					valHighest[1] = value
				elseif value > valHighest[2] then
					valHighest[3] = valHighest[2]
					valHighest[2] = value
				elseif value > valHighest[3] then valHighest[3] = value 
				end
			end
			
			-- 1 G, Hunk of Rift Crystal, and Giant Hunk of Rift Crystal are excluded since they're converted to currency as soon as you obtain them
			if not (id >= 93 and id <= 95) then itemData[id] = {name = name, category = category, categorySub = categorySub, value = value} end
		end
	end
	
	local valCeil = valHighest[3] -- Value ceiling will be based on the 3rd most expensive material
	
	for id, item in pairs(itemData) do -- Materials that exceed the value ceiling will be to set to the ceiling's value
		local val = item.value
		local category = item.category
		
		if category == "Material" and val > valCeil then item.value = valCeil end
	end

	if config.DEBUG_MODE then json.dump_file("ESO/Item Data.json", itemData) end
end

local function allocateMaterials()
	if config.USE_TIER_BASED then
		local otherMats = {}
		
		if config.ADD_FERRYSTONE then otherMats[80] = {tier = "T2", type = "Misc", trait = "Treasure"} end -- Ferrystone is added as a T2 material in the Misc type and Treasure trait lists
		if config.ADD_WORMSLIFE_CRYSTAL then otherMats[473] = {tier = "T3", type = "Misc", trait = "None"} end -- Wormslife Crystal is added as a T3 material in the Misc type list
			
		if config.ADD_GLIMMERCOAL then
			otherMats[332] = {tier = "T2", type = "Misc", trait = "None"} -- Glimmercoal is added as a T2 material in the Misc type list
			table.insert(abundantMats, 332) -- Glimmercoal is given the Abundant trait
		end
		
		if config.ADD_GEMSTONES then
			for id = 344, 346 do otherMats[id] = {tier = "T2", type = "Misc", trait = "None"} end -- Gemstones are added as T2 materials in the Misc type list - already has Treasure trait so that variable is set to "None"
			for i = 4, 2, -1 do table.remove(matTypes.Uncategorized.T2, i) end -- Gemstones are removed from the Uncategorized type list
		end	
		
		if MSI_installed then	
			-- Eternal Wakestone can become a potential upgrade material if any of the following conditions are met:
			-- 1. MSI's Improve Crystal Shops option is enabled
			-- 2. MSI's Apply Misc Tweaks option is disabled
			-- 3. UDD2P's Eternal Wokestone Fix is disabled
			local eternalWakestoneCond = (configMSI.IMPROVE_CRYSTAL_SHOPS or not configMSI.APPLY_MISC_TWEAKS) or not configUDD2P.ETERNAL_WOKESTONE_FIX
			
			if config.ADD_ETERNAL_WAKESTONE and eternalWakestoneCond then otherMats[76] = {tier = "T3", type = "Uncategorized", trait = "Immortal"} end -- Eternal Wakestone is added as a T3 material in the Immortal trait list
			
			if configMSI.IMPROVE_CRYSTAL_SHOPS then
				-- Eternal Ferrystone is added as a T3 material in the Misc Type and Treasure trait lists
				-- Jadeite Orb is added as a T3 material in the Misc type and the Treasure trait lists
				if config.ADD_ETERNAL_FERRYSTONE then otherMats[619] = {tier = "T3", type = "Misc", trait = "Treasure"} end
				if config.ADD_JADEITE_ORB and configMSI.RC_SHOPS_SELL_KEY_ITEMS then otherMats[365] = {tier = "T3", type = "Misc", trait = "Treasure"} end
			end
		end
			
		if otherMats then 
			for id, data in pairs(otherMats) do
				table.insert(matTypes[data.type][data.tier], id)
				
				if data.trait ~= "None" then table.insert(matTraits[data.trait][data.tier], id) end
			end
		end
	end
	
	for type, data in pairs(matTypes) do
		for tier, list in pairs(data) do
			for _, id in pairs(list) do
				local item  = itemData[id]
				local tierFinal = (type == "Uncategorized" and "Untiered") or tier
				
				if not materialData[id] then materialData[id] = {category = item.category, name = item.name, value = item.value, tier = tierFinal, type = type, boss = false, abundant = false} end
				if tierFinal ~= "Untiered" then table.insert(matTiers[tier], id) end
			end
		end
	end
	
	for _, id in pairs(bossMats) do materialData[id].boss = true end
	for _, id in pairs(abundantMats) do	materialData[id].abundant = true end
	
	for i = 1, 3 do
		table.sort(matTiers["T" .. i], function(i1, i2)
			local item1 = materialData[i1]
			local item2 = materialData[i2]
			local i1Score = item1.value * ((item1.boss and 2) or 1) * ((item1.abundant and 0.8) or 1)
			local i2Score = item2.value * ((item2.boss and 2) or 1) * ((item2.abundant and 0.8) or 1)
			
			return (i1Score == i2Score and i1 < i2) or i1Score < i2Score end
		)
	end
	
	if config.DEBUG_MODE then 
		json.dump_file("ESO/Material Data.json", materialData)
		json.dump_file("ESO/Material Data - By Type.json", matTypes)
		json.dump_file("ESO/Material Data - By Tier.json", matTiers)
		json.dump_file("ESO/Material Data - By Trait.json", matTraits)
	end
end

local function computeStatsDiff(id, item, type)
	local category = item.category
	local job = (category == "Shield" and "Fighter - Shield") or item.job
	local statsDiffAvg = 0
	local statCount = 0
	
	if type == "Weapon" then
		for _, stat in pairs(offensiveStats) do
			local statBase = item[stat]
			
			if statBase > 0 then
				local statBiS = bestWeapons[job][stat]
				local statWiS = worstWeapons[job][stat]
				local statMaxDiff = statBiS - statWiS
				local statDiff = statBiS - statBase
				
				if statDiff > 0 then statsDiffAvg = statsDiffAvg + (statDiff / statMaxDiff) end
			end
		end
		
		return statsDiffAvg
	else	
		for _, stat in pairs(defensiveStats) do
			local statBase = item[stat]
			
			if statBase > 0 then
				for _, currJob in pairs(item.compatibleJobs) do
					local statBiS = bestArmor[category][currJob][stat]
					local statWiS = worstArmor[category][currJob][stat]
					local statMaxDiff = statBiS - statWiS
					local statDiff = statBiS - statBase
					
					statCount = statCount + 1
					
					if statDiff > 0 then statsDiffAvg = statsDiffAvg + (statDiff / statMaxDiff) end
				end
			end
		end
		
		return statsDiffAvg / math.max(statCount, 1)
	end
end

local function collectGearByTier(type)	
	local equipData = getEquipData(type)
	local gearInTiers = {T1 = {}, T2 = {}, T3 = {}}
	local statDiff = {}
	
	for id, item in pairs(equipData) do
		local lv = item.lv
		local tier = (lv < lvT2 and "T1") or (lv < lvT3 and "T2") or "T3"
		
		if type ~= "Misc" then statDiff[id] = computeStatsDiff(id, item, type) end
		
		table.insert(gearInTiers[tier], id)
	end
	
	for i = 1, 3 do
		table.sort(gearInTiers["T" .. i], function(i1, i2)
			local i1Lv = equipData[i1].lv
			local i2Lv = equipData[i2].lv
				
			if i1Lv == i2Lv then
				if type ~= "Misc" then
					local i1StatsDiff = statDiff[i1]
					local i2StatsDiff = statDiff[i2]
				
					return (i1StatsDiff == i2StatsDiff and i1 < i2) or i1StatsDiff < i2StatsDiff
				else
					local i1ValDiff = miscData[i1].value
					local i2ValDiff = miscData[i2].value
					
					return (i1ValDiff == i2ValDiff and i1 < i2) or i1ValDiff < i2ValDiff
				end
			else return i1Lv < i2Lv
			end
		end)
	end
	
	return gearInTiers
end

local function replaceMaterial(matId, upgradeLv, id, markFirst)
	local tier = "T" .. upgradeLv
	local item = getDataById(id)
	local currMat = materialData[matId]
	local effectList = (markFirst and {Element = item.elementPwr, Poison = item.poisonPwr, Sleep = item.sleepPwr, Silence = item.silencePwr, Petrify = item.petrifyPwr, Wet = item.wetPwr, Tar = item.tarPwr}) or nil
	
	if currMat then
		local matType = currMat.type
		local matTrait = "None"
		
		if config.CONSIDER_SPECIAL_TRAITS and item.category == "Weapon" and markFirst then -- The type of the 1st material gets replaced if the item is a weapon that's elemental or can inflict debilitations				
			if id == 1513 or id == 1906 then matTrait = "Immortal"
			elseif id == 1413 or id == 2103 then matTrait = "Treasure"
			elseif id == 1010 or id == 1207 or id == 1610 or id == 2010 then matTrait = "Power"
			elseif id == 1804 or id == 2210 then matTrait = "Petrify"
			elseif item.markElemental or item.markStatus then
				local effectCount = 0

				for type, effect in pairs(effectList) do
					if effect > 0 then
						effectCount = effectCount + 1
						
						if effectCount > 1 then 
							matTrait = "Multi"
							break
						elseif type == "Element" then matTrait = item.elementType
						else matTrait = type
						end
					end
				end
			end
		end
		
		-- Uncategorized materials are replaced with Misc type materials - if there's more than 1 material found in a list, then 1 will be selected at random
		matId = (matTrait == "None" and ((matType == "Uncategorized" and matTypes.Misc[tier]) or matTypes[matType][tier])) or matTraits[matTrait][tier]
		matId = matId[math.random(#matId)]
	end
	
	return matId
end

local function rerollSimilarMaterial(mat1Id, mat2Id, tier)	
	local mat1Data = materialData[mat1Id]
	local mat2Data = materialData[mat2Id]	
	
	if (mat1Data and mat2Data) and (mat1Id == mat2Id or mat1Data.type == mat2Data.type) then -- The 2nd material is replaced with a random one if it's the same as the 1st material or they're the same type
		while mat1Id == mat2Id or mat1Data.type == mat2Data.type do
			mat2Id = matTiers[tier][math.random(#matTiers[tier])]
			mat2Data = materialData[mat2Id]
		end
	end
	
	return mat2Id
end

local function remeasureMaterialQuantity(matId, matQty)
	local matQtyFinal = matQty
	local currMat = materialData[matId]
	
	if currMat then
		local tier = currMat.tier
		
		if matId == 78 or (matId >= 344 and matId <= 346) then matQtyFinal = 2
		elseif (currMat.type == "Uncategorized" and matId ~= 85) or matId == 365 or matId == 473 then matQtyFinal = 1
		else matQtyFinal = config.BASE_QTY / ((currMat.boss and 2) or 1) * ((currMat.abundant and 1.25) or 1) * ((tier == "T3" and 0.75) or (tier == "T1" and 1.25) or 1)
		end
	
		matQtyFinal = roundUp(matQtyFinal)
	end
	
	return matQtyFinal
end

local function prepareMaterialAssignData(type)
	local equipData = getEquipData(type)
	local nowUpgradable = (type == "Weapon" and weaponNowUpgradable) or (type == "Armor" and armorNowUpgradable) or miscNowUpgradable
	local gearInTiers = collectGearByTier(type)
	local gearCount = 0
	local matsCount = 0
	local gearSorted = {}
	local matsSorted = {}
	local matAssignData = {}
	local matAssignDataReadable = {}
	
	for i = 1, 3 do 
		gearCount = gearCount + #gearInTiers["T" .. i]
		matsCount = matsCount + #matTiers["T" .. i]
	end
	
	for tier, data in pairs(gearInTiers) do
		for ind, id in pairs(data) do gearSorted[id] = ind + ((tier ~= "T1" and #gearInTiers.T1) or 0) + ((tier == "T3" and #gearInTiers.T2) or 0) end
	end
	
	for tier, data in pairs(matTiers) do
		for ind, id in pairs(data) do matsSorted[ind + ((tier ~= "T1" and #matTiers.T1) or 0) + ((tier == "T3" and #matTiers.T2) or 0)] = id end
	end
	
	for id, item in pairs(equipData) do
		if not (config.KEEP_EXISTING_REQUIREMENTS and not nowUpgradable[id]) then
			local lv = item.lv
			local tier = item.tier
			local rank = gearSorted[id]
			local matRank = math.floor(((rank - 1) / gearCount) * matsCount) + 1 -- Doesn't use the roundUp function to ensure the material is properly ranked
			local matReq = {}
			local matQty = {}
			
			matRank = math.max(1, math.min(matsCount, matRank))
			
			if config.USE_ADJACENT_SELECTION then							
				for ind = 1, 5 do matReq[ind] = matsSorted[matRank + (ind - ((matRank == 1 and 1) or (matRank == 2 and 2) or (matRank == matsCount - 1 and 4) or (matRank == matsCount and 5) or 3))] end
			else
				local used = {}
				
				for ind = 1, 5 do
					local mat = 0
					
					repeat mat = matTiers[tier][math.random(#matTiers[tier])] until not used[mat]
					
					used[mat] = true
					matReq[ind] = mat
				end
			end
			
			for ind = 1, 5 do matQty[ind] = (materialData[matReq[ind]].boss and 1) or (matReq[ind] == 359 and 4) or 2 end
			
			matAssignData[id] = {matReq = matReq, matQty = matQty}
	
			if config.DEBUG_MODE then				
				matAssignDataReadable[id] = {
					name = item.name,
					tier = tier,
					rank = rank .. "/" .. gearCount,
					matReq = {}
				}
				
				for _, mat in pairs(matAssignData[id].matReq) do matAssignDataReadable[id].matReq[mat] = materialData[mat].name end
			end
		end
	end
	
	if config.DEBUG_MODE then json.dump_file("ESO/" .. type .. " Data - Material Assignments.json", matAssignDataReadable) end
	
	return matAssignData
end

local function assignNewMaterials(equipDict, type)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	local equipData = getEquipData(type)
	local qtyType = (config.ASSIGN_ALWAYS_TWO and "alwaysTwo") or "vanillaLike"
	local distType = (config.USE_TIER_BASED and "tb") or "vanilla"
	local currTable = matAssignIndices[qtyType][distType]
	local matAssignData = prepareMaterialAssignData(type)
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local paramsArray = enum:get_Current().value
		
		if equipData[id] and matAssignData[id] then	
			local currAssignData = matAssignData[id]
			local matReq = currAssignData.matReq
			local matQty = currAssignData.matQty
			
			for i = 0, paramsArray:get_Length() - 1 do
				local param = paramsArray[i]
				local upgradeLv = param._EnhanceNo + 1
				local smithStyle = smithingStyle[param._Type]
				
				if smithStyle ~= "Wyrmfire" then
					local stylePair = ((smithStyle == "Vermundian" or smithStyle == "Battahli") and "VB") or "ED"
					
					for ind = 1, 2 do
						local assignInd = 0
						local matParam = matParamList[ind]
						
						if config.USE_TIER_BASED then assignInd = currTable[smithStyle][ind]
						else assignInd = ((not config.ASSIGN_ALWAYS_TWO and upgradeLv < 2) and 0) or currTable[upgradeLv][(((not config.ASSIGN_ALWAYS_TWO and upgradeLv == 2) or upgradeLv == 1) and stylePair) or smithStyle][ind]
						end
						
						param[matParam.id] = (assignInd > 0 and matReq[assignInd]) or 0
						param[matParam.qty] = (assignInd > 0 and matQty[assignInd]) or 0
					end
				end
			end
		end
	end
end

local function modifyMaterialRequirements(equipDict, type)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	local equipData = getEquipData(type)
	local nowUpgradable = (type == "Weapon" and weaponNowUpgradable) or (type == "Armor" and armorNowUpgradable) or miscNowUpgradable
	local markKeepReqs = config.KEEP_EXISTING_REQUIREMENTS and (config.USE_BASIC_STAT_COMPUTATION or (not config.REWORK_UPGRADE_PROGRESSION and config.USE_TIER_BASED))
	
	if not config.KEEP_EXISTING_REQUIREMENTS and (config.REWORK_UPGRADE_PROGRESSION and config.USE_TIER_BASED) then
		while enum:MoveNext() do
			local id = enum:get_Current().key
			local paramsArray = enum:get_Current().value
		
			if equipData[id] then
				for i = 0, paramsArray:get_Length() - 1 do
					local param = paramsArray[i]
					local upgradeLv = param._EnhanceNo + 1
					local smithStyle = smithingStyle[param._Type]
					
					if smithStyle ~= "Wyrmfire" and upgradeLv < 3 then -- Tier-Based copies Lv.3 requirements as reference for material type
						local indAdd = (config.USE_TIER_BASED and 3 - upgradeLv) or 1
						local nextParam = paramsArray[i + indAdd]
					
						for ind = 1, 2 do
							local matParam = matParamList[ind]
							
							param[matParam.id] = nextParam[matParam.id]
							param[matParam.qty] = nextParam[matParam.qty]
						end
					end
				end
			end
		end
		
		enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	end
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local paramsArray = enum:get_Current().value
		local item = equipData[id]
			
		if item and not (config.KEEP_EXISTING_REQUIREMENTS and not nowUpgradable[id]) then
			local category = item.category
			
			for i = 0, paramsArray:get_Length() - 1 do
				local param = paramsArray[i]
				local upgradeLv = param._EnhanceNo + 1
				local smithStyle = smithingStyle[param._Type]
				
				if smithStyle ~= "Wyrmfire" then						
					for ind = 1, 2 do
						local matParam = matParamList[ind]
						local matId = param[matParam.id]
						local matQty = param[matParam.qty]
						local firstMat = param[matParamList[1].id]
						
						if config.REWORK_UPGRADE_PROGRESSION then
							if config.USE_TIER_BASED then
								matId = replaceMaterial(matId, upgradeLv, id, ind == 1)
								matId = (ind == 2 and rerollSimilarMaterial(firstMat, matId, "T" .. upgradeLv)) or matId
							end
							
							param[matParam.id] = matId
						end
						
						if config.REMEASURE_MATERIAL_QUANTITIES then						
							if matId > 0 then matQty = remeasureMaterialQuantity(matId, matQty) / ((category == "Face" and 2) or 1) end
							
							param[matParam.qty] = math.max(1, roundUp(matQty * enhanceItemMult))
						end
					end
				end
			end
		end
	end
end

local function removeVocationRequirements(equipDict)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local param = enum:get_Current().value
		local categoryGroup = (getDataById(id) and getDataById(id).categoryGroup) or nil

		if categoryGroup ~= nil and ((config.INCLUDE_WEAPONS and categoryGroup == "Weapon") or categoryGroup == "Armor") then param._Job = 1022 end
	end
end

local function generateEnhanceData(equipDict, type)
	local enum = equipDict:call("System.Collections.IEnumerable.GetEnumerator()")
	local equipData = getEquipData(type)
	local equipEnhanceData = {}
	
	while enum:MoveNext() do
		local id = enum:get_Current().key
		local paramsArray = enum:get_Current().value
		
		if equipData[id] then			
			equipEnhanceData[id] = {}
			
			for _, style in pairs(smithingStyle) do
				equipEnhanceData[id][style] = {}
				
				if style == "Wyrmfire" then equipEnhanceData[id][style]["Lv.Max"] = {}
				else
					for _, lv in pairs(upgradeLevel) do	equipEnhanceData[id][style][lv] = {} end
				end
			end
			
			for i = 0, paramsArray:get_Length() - 1 do
				local param = paramsArray[i]
				local smithStyle = smithingStyle[param._Type]
				local upgradeLv = (smithStyle == "Wyrmfire" and "Lv.Max") or upgradeLevel[param._EnhanceNo + 1]
				local currEntry = equipEnhanceData[id][smithStyle][upgradeLv]
				
				currEntry.wgtAdjR = param._WeightRate
				currEntry.wgtAdjF = param._Weight
				currEntry.cost = param._NeedMoney
				currEntry.mat1Id = param._NeedItemId0
				currEntry.mat1Qty = param._NeedItemNum0
				currEntry.mat2Id = param._NeedItemId1
				currEntry.mat2Qty = param._NeedItemNum1
				
				if type == "Weapon" then
					currEntry.strInc = param._PhysicalAttack
					currEntry.magInc = param._MagicAttack
					currEntry.kdpInc = param._Blow
					currEntry.kdgInc = param._BlowGuard
					currEntry.staReduceInc = param._StaminaReduce
					currEntry.elementPwrInc = param._ElementStore
					currEntry.bashPwrInc = param._StrikeStore
					currEntry.poisonPwrInc = param._PoisonStore
					currEntry.sleepPwrInc = param._SleepStore
					currEntry.silencePwrInc = param._SilentStore
					currEntry.petrifyPwrInc = param._StoneStore
					currEntry.wetPwrInc = param._WaterStore
					currEntry.tarPwrInc = param._OilStore
				else
					currEntry.defInc = param._PhysicalDefence
					currEntry.mdfInc = param._MagicDefence
					currEntry.kdrInc = param._BlowResistRate
					currEntry.slashDefInc = param._SlashDefenceRate
					currEntry.strikeDefInc = param._StrikeDefenceRate
					currEntry.fireDefInc = param._FireDefence
					currEntry.iceDefInc = param._IceDefence
					currEntry.thunderDefInc = param._ThunderDefence
					currEntry.lightDefInc = param._LightDefence
					currEntry.burnResInc = param._FireResist
					currEntry.freezeResInc = param._IceResist
					currEntry.poisonResInc = param._PoisonResist
					currEntry.sleepResInc = param._SleepResist
					currEntry.silenceResInc = param._SilentResist
					currEntry.petrifyResInc = param._StoneResist
					currEntry.wetResInc = param._WaterResist
					currEntry.tarResInc = param._OilResist
					currEntry.faintResInc = param._FaintResist
				end
			end
		end
	end

	if config.DEBUG_MODE then json.dump_file("ESO/" .. type .. " Data - Upgrade Stats.json", equipEnhanceData) end
end

-- Dark Arisen compatibility: do not let an exception turn the startup callback
-- into a per-frame retry loop. The load is considered failed and should be
-- followed by a full restart with this mod disabled, NOT continued play.
local function compatTrace(message)
    if log and log.info then log.info("[ESO Base-Game Compat] " .. message) end
end

local function compatError(message)
    if log and log.error then log.error("[ESO Base-Game Compat] " .. message) end
end

fns.run_once["ESO"] = function()
    if not (startup.is_game_data_ready() and startup.is_startup()) then return end
    if fns.run_once["GPO - Economy tweaks"] or fns.run_once["Balanced augments"] then return end

    local phase = "initialization"
    local ok, err = xpcall(function()
        local itemDataDict = assert(ItemManager and ItemManager._ItemDataDict, "ItemManager item dictionary unavailable")
        local weaponEnhanceDict = assert(ItemManager._WeaponEnhanceDict, "weapon enhancements unavailable")
        local armorEnhanceDict = assert(ItemManager._ArmorEnhanceDict, "armor enhancements unavailable")

        math.randomseed(34)
        phase = "prepareLists"
        prepareLists(itemDataDict)
        if config.REBALANCE_EQUIPMENT then
            phase = "rebalanceEquipment"
            rebalanceEquipment(itemDataDict)
        end
        phase = "generateEquipmentData"
        generateEquipmentData(itemDataDict)
        phase = "initializeStatsData"
        initializeStatsData()
        phase = "collectBestandWorstStats"
        collectBestandWorstStats()
        phase = "modifyEquipmentLevels"
        modifyEquipmentLevels(itemDataDict)
        if config.ALTER_UNSELECTED_BEST_GEAR then
            phase = "alterUnselectedBestGear"
            alterUnselectedBestGear(itemDataDict)
        end
        if config.PROVIDE_ENHANCE_DATA_FOR_NON_UPGRADABLE_GEAR then
            phase = "createEnhanceData"
            createEnhanceData(weaponEnhanceDict, armorEnhanceDict)
        end
        phase = "modifyWeaponEnhanceData"
        modifyWeaponEnhanceData(weaponEnhanceDict)
        phase = "modifyArmorEnhanceData"
        modifyArmorEnhanceData(armorEnhanceDict, "Armor")
        if markUpgradableMisc then
            phase = "modifyMiscEnhanceData"
            modifyArmorEnhanceData(armorEnhanceDict, "Misc")
        end

        if not config.COMPAT_SKIP_MATERIAL_PIPELINE then
            phase = "generateItemData"
            generateItemData(itemDataDict)
            phase = "allocateMaterials"
            allocateMaterials()
            if config.ASSIGN_NEW_MATERIALS then
                phase = "assignNewMaterials"
                assignNewMaterials(weaponEnhanceDict, "Weapon")
                assignNewMaterials(armorEnhanceDict, "Armor")
                if markUpgradableMisc then assignNewMaterials(armorEnhanceDict, "Misc") end
            end
            phase = "modifyMaterialRequirements"
            modifyMaterialRequirements(weaponEnhanceDict, "Weapon")
            modifyMaterialRequirements(armorEnhanceDict, "Armor")
            if markUpgradableMisc then modifyMaterialRequirements(armorEnhanceDict, "Misc") end
        end
        if config.REMOVE_VOCATION_REQUIREMENTS and not MSI_installed then
            phase = "removeVocationRequirements"
            removeVocationRequirements(itemDataDict)
        end
        if config.DEBUG_MODE then
            phase = "generateEnhanceData (debug)"
            generateEnhanceData(weaponEnhanceDict, "Weapon")
            generateEnhanceData(armorEnhanceDict, "Armor")
            generateEnhanceData(armorEnhanceDict, "Misc")
        end
        math.randomseed(roundUp(os.clock() * 1000))
    end, function(message)
        return (debug and debug.traceback and debug.traceback(tostring(message), 2)) or tostring(message)
    end)

    if ok then
        compatTrace("Base-game equipment scaling applied (expansion equipment excluded).")
    else
        compatError("FAILED during " .. phase .. ": " .. tostring(err))
        compatError("EXIT WITHOUT SAVING. Disable ESO and restart before trying again.")
    end
    -- _NickCore must not repeat an unsuccessful startup on each subsequent frame.
    return true
end
