local config = {}

-- Dark Arisen compatibility: process only known base-game equipment IDs.
-- DLC/custom equipment is left untouched; original ESO scaling math is retained.
-- Keep vanilla smithing requirements and disable ring/misc enhancement changes
-- until the expansion-specific data structures can be handled safely.
config.COMPAT_BASE_GAME_ONLY = true
config.COMPAT_SKIP_MATERIAL_PIPELINE = true

-- JSON files are printed for debugging
config.DEBUG_MODE = false

-- Some items have been altered, mostly due to preference and/or balancing reasons
-- If the Aggrandize Smithing Styles option is enabled, all weapons now have halved base effect power
-- Some ring effects adapt to mods that change values of augments while others are straight-up improved
-- If misc gear are given enhance data, then rings that give immunity to debilitations only give 80% resistance
config.REBALANCE_EQUIPMENT = true
config.MODIFY_RINGS = false

-- By default, only vanilla equipment are qualified, but this can be disabled so that even CE-added gear can be selected
-- You can choose to disqualify any equipment that aren't exclusively obtained in the Unmoored World - Molten Fury and Cinderspine are exempted because they have the highest MAG stat for Fighter and Warrior, respectively
-- Only armor that are usable by a few vocations are qualified as best-in-slot, but you can increase the vocation count limit to include more items
-- Note that CE-added items can greatly affect gold costs if USE_CUSTOM_HIGHEST_VALUES is disabled
-- By default, Mystic Spearhand's best-in-slot body armor gets a 25% nerf to its stats if it isn't exclusive to that vocation, because of Vashara Scaleskin and Silhouette of Sorcery
config.DISQUALIFY_MODDED_GEAR = true
config.INCLUDE_ONLY_ENDGAME = true
config.LIMIT_CANDIDATES = true
config.VOCATION_COUNT_LIMIT = 3 -- Recommended 2 - 3
config.NERF_MS_BODY_ARMOR = true

-- Equipment levels are computed to be used on other features, like modifying material requirements, etc...
-- Don't touch any of the variables below unless you know what you're doing
config.MAX_LEVEL = 40
config.T2_MIN_LEVEL = math.floor((config.MAX_LEVEL * 0.4) + 0.5)
config.T3_MIN_LEVEL = math.floor((config.MAX_LEVEL * 0.75) + 0.5)
config.ADVANCED_VOCATION_MIN_LEVEL = 8

-- Equipment that are stronger than what ESO selects as best-in-slot will be readjusted - this is primarily for CE-added equipment that have strong stats, either on purpose or because they weren't upgradable
-- You can choose to preserve the stats of vanilla gear
config.ALTER_UNSELECTED_BEST_GEAR = true
config.EXCLUDE_VANILLA_GEAR = false

-- Gear that have no enhance data are now given empty templates which are then filled by this mod
-- Cloaks and facewear can become upgradable as well - they have low defenses but gain more resistances in return
-- On upgrades, facewear receive only half of the stat gains of cloaks but they also require less resources
-- If enabled, if a cloak or facewear doesn't have resistance on certain categories, then they get a random one on those categories
config.PROVIDE_ENHANCE_DATA_FOR_NON_UPGRADABLE_GEAR = false
config.INCLUDE_MISC_GEAR = true
config.MODIFY_RESISTANCES = false

-- Elemental weapons used by physical vocations get a nerf split between their final STR and KDP
-- Elemental weapons used by magick vocations get a nerf to their final KDP
-- Maces and hammers have less final STR but higher final KDP than their bladed counterparts
-- Debilitating weapons get a nerf to their final KDP
-- You can now choose to apply these adjustments to base stats as well, not just final stats, but the stat adjustment rate is halved
config.ADJUST_SPECIAL_WEAPONS = true
config.STAT_ADJUST_RATE = 0.1
config.ENCHANT_RATE = 0.17000000178814 -- Got this value by using Nick's Devtools >> Damage Tracer >> All DamageInfo Fields

-- Even when fully upgraded, earlygame equipment are still be somewhat weaker than endgame equipment
-- Max gap determines how weak earlygame equipment can be
-- If enabled, level-based stats scaling can be disabled for vanilla-like stat upgrades
-- This doesn't apply to misc gear because they hardly have any stats in vanilla
-- You can choose to exclude armor, affecting only weapons
config.UNEQUALIZE_FINAL_STATS = true
config.MAX_GAP = 0.1 -- Recommended: 0.1 - 0.2
config.USE_BASIC_STAT_COMPUTATION = false
config.EXCLUDE_ARMOR = false

-- Gold costs for upgrades are dynamically calculated based on stat differences and item type
-- If Basic Stat Computation is enabled, then this option is automatically ignored
-- Using the highest value variables will skip processing and can also prevent upgrades from being too cheap or expensive if a CE-added item is selected as best-in-slot
-- Misc gear will always use the highest value variable even if USE_CUSTOM_HIGHEST_VALUES is disabled
-- Note that any price multipliers from other mods can affect the final upgrade prices
config.RECALCULATE_UPGRADE_COSTS = false
config.USE_CUSTOM_HIGHEST_VALUES = true
config.HIGH_VAL_WEAPON = 75000
config.HIGH_VAL_SHIELD = 40000
config.HIGH_VAL_HEAD = 44900
config.HIGH_VAL_BODY = 80000
config.HIGH_VAL_LEGS = 56700
config.HIGH_VAL_MISC = 60540

-- Upgrades now also affect effect power and resistances according to smithing style
-- Effect power and resistances are split into 3 categories, and a certain smithing style specializes on 1 of them - Vermundian gives a moderate boost to all of them
-- The variables below affect the gains given by BOOST_WYRMFIRE_UPGRADES and AGGRANDIZE_SMITHING_STYLES
config.AGGRANDIZE_SMITHING_STYLES = true
config.MAX_RES_PHYS = 5
config.MAX_RES_ELEMENT = 15
config.MAX_RES_STATUS = 25

-- Wyrmfire upgrades give various bonuses to equipment but require more WLC to compensate for the changes
-- By default, wyrmfire upgrades now only deduct 25% of the gear's weight
config.BOOST_WYRMFIRE_UPGRADES = true
config.WYRMFIRE_STAT_BONUS = 0.2
config.HALVE_WEIGHT_REDUCTION = true

-- Upgrade progression is reworked so that upgrades don't ask for easily obtainable materials for higher levels
-- Tier-Based makes equipment require 2 types of materials that increase in tier according to upgrade level
-- If the Tier-Based option is disabled, then materials are assigned similarly to vanilla
-- When using Tier-Based material replacement, elemental and debilitating weapons have their 1st material requirements replaced with items from a list that matches their specific trait
config.REWORK_UPGRADE_PROGRESSION = false
config.USE_TIER_BASED = true
config.CONSIDER_SPECIAL_TRAITS = true

-- Equipment are given new material requirements
-- Adjacent Selection ranks equipment depending on various factors, then selects materials corresponding to that rank
-- If Adjacent Selection is disabled, materials will be selected randomly
-- By default, always 2 materials are assigned - disabling this makes material requirements similar to vanilla
-- You can choose to exclude equipment with existing material requirements
-- Material quantities are remeasured starting with a base amount that's later affected by certain material traits
config.ASSIGN_NEW_MATERIALS = false
config.USE_ADJACENT_SELECTION = true
config.ASSIGN_ALWAYS_TWO = true
config.KEEP_EXISTING_REQUIREMENTS = true
config.REMEASURE_MATERIAL_QUANTITIES = false
config.BASE_QTY = 4 -- Recommended: 2 - 9

-- Certain items can now become potential upgrade materials
-- Some items depend on certain options from either this mod or others
-- Eternal Wakestone will only appear as a material for upgrades that specifically require Wakestones or Wakestone Shards when using Tier-Based Upgrade Progression
config.ADD_ETERNAL_WAKESTONE = true
config.ADD_FERRYSTONE = true
config.ADD_WORMSLIFE_CRYSTAL = false
config.ADD_GLIMMERCOAL = true
config.ADD_GEMSTONES = true
config.ADD_ETERNAL_FERRYSTONE = false
config.ADD_JADEITE_ORB = false

-- If enabled, equipment are now usable by all vocations
-- This is applied after everything else has been computed, so it won't affect final stats
-- You can choose to include weapons as well, not just armor
-- If MSI is installed, then that mod will do it instead so that it doesn't affect gear distribution
config.REMOVE_VOCATION_REQUIREMENTS = false
config.INCLUDE_WEAPONS = false

return config