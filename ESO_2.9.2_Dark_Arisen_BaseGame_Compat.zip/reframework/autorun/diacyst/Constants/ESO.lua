local constants = {}

constants.vocationList = {[2] = "Fighter", [4] = "Archer", [8] = "Mage", [16] = "Thief", [32] = "Warrior", [64] = "Sorcerer", [128] = "Mystic Spearhand", [256] = "Magick Archer", [512] = "Trickster"}
constants.itemCategory = {[0] = "Use", [1] = "Material", [2] = "Other", [3] = "Equip"}
constants.itemSubCategory = {[0] = "Heal", [1] = "Buff", [2] = "Material", [3] = "Special", [4] = "Quest", [5] = "Book", [6] = "Arrow", [7] = "Maister Scroll", [8] = "Specialization Tome", [9] = "Grimoire", [10] = "Online"}
constants.equipCategory = {[0] = "Weapon", [1] = "Shield", [2] = "Head", [3] = "Body", [4] = "Legs", [5] = "Cloak", [6] = "Ring", [7] = "Face"}
constants.smithingStyle = {[0] = "Vermundian", [1] = "Battahli", [2] = "Elven", [3] = "Dwarven", [4] = "Wyrmfire"}
constants.upgradeLevel = {[1] = "Lv.1", [2] = "Lv.2", [3] = "Lv.3"}
constants.elementType = {[0] = "None", [1] = "Fire", [2] = "Ice", [3] = "Thunder", [4] = "Holy"}
constants.armorType = {"Head", "Body", "Legs"}
constants.offensiveStats = {"str", "mag", "kdp", "kdg"}
constants.defensiveStats = {"def", "mdf", "kdr"}

constants.effectParamsBody = {elementPwr = "_ElementStore", poisonPwr = "_PoisonStore", petrifyPwr = "_StoneStore", wetPwr = "_WaterStore", tarPwr = "_OilStore"}
constants.effectParamsMind = {strikePwr = "_StrikeStore", sleepPwr = "_SleepStore", silencePwr = "_SilentStore"}
constants.resParamsDef = {slashDef = "_SlashDefenceRate", strikeDef = "_StrikeDefenceRate", fireDef = "_FireDefence", iceDef = "_IceDefence", thunderDef = "_ThunderDefence", lightDef = "_LightDefence"}
constants.resParamsResBody = {burnRes = "_FireResist", freezeRes = "_IceResist", poisonRes = "_PoisonResist", petrifyRes = "_StoneResist", wetRes = "_WaterResist", tarRes = "_OilResist"}
constants.resParamsResMind = {sleepRes = "_SleepResist", silenceRes = "_SilentResist", faintRes = "_FaintResist"}
constants.matParamList = {{id = "_NeedItemId0", qty = "_NeedItemNum0"}, {id = "_NeedItemId1", qty = "_NeedItemNum1"}}

constants.wlcWeapons = {1010, 2209, 1706, 1514, 1411, 1207, 1606, 2010, 1908, 2105}
constants.wlcWeaponsExtra = {1009, 2208, 1805, 1512, 1414, 1303, 1610, 2007, 1907, 2104}
constants.wlcArmor = {4015, 4026, 4087, 4103, 4051, 4039, 4038, 4071, 4107, 5015, 5028, 5087, 5103, 5051, 5060, 5039, 5071, 5107, 6026, 6019, 6087, 6103, 6051, 6038, 6068}
constants.wlcArmorExtra = {4014, 4102, 4096, 4029, 4062, 4073, 5014, 5131, 5126, 5096, 5029, 5062, 5038, 5114, 5073, 6029, 6014, 6096}

constants.weaponStatMults = {
	Vermundian = {str = 1.35, mag = 1.35, kdp = 1.1},
	Battahli = {str = 1.525, mag = 1.275, kdp = 1},
	Elven = {str = 1.275, mag = 1.525, kdp = 1},
	Dwarven = {str = 1.275, mag = 1.275, kdp = 1.25}
}

constants.armorStatMults = {
	Vermundian = {def = 1.35, mdf = 1.35, kdr = 3.3},
	Battahli = {def = 1.525, mdf = 1.275, kdr = 3},
	Elven = {def = 1.275, mdf = 1.525, kdr = 3},
	Dwarven = {def = 1.275, mdf = 1.275, kdr = 3.75}
}

constants.secondaryStatMults = {
	Vermundian = {Phys = 0.6667, Element = 0.6667, Status = 0.6667},
	Battahli = {Phys = 0.3333, Element = 0.3333, Status = 1},
	Elven = {Phys = 0.3333, Element = 1, Status = 0.3333},
	Dwarven = {Phys = 1, Element = 0.3333, Status = 0.3333}
}

constants.matAssignIndices = {
	alwaysTwo = {
		tb = {Vermundian = {3, 4}, Battahli = {2, 5}, Elven = {3, 5}, Dwarven = {4, 5}},
		vanilla = {
			{VB = {1, 2}, ED = {1, 3}},
			{Vermundian = {1, 4}, Battahli = {2, 3}, Elven = {2, 4}, Dwarven = {1, 5}},
			{Vermundian = {3, 4}, Battahli = {2, 5}, Elven = {3, 5}, Dwarven = {4, 5}}
		}
	},
	vanillaLike = {
		tb = {Vermundian = {2, 3}, Battahli = {2, 4}, Elven = {3, 4}, Dwarven = {3, 5}},
		vanilla = {
			[2] = {VB = {1, 0}, ED = {1, 2}},
			[3] = {Vermundian = {2, 3}, Battahli = {2, 4}, Elven = {3, 4}, Dwarven = {3, 5}}
		}
	}
}

constants.matTypes = {
	Canine = {
		T1 = {213}, -- Small Fang
		T2 = {214}, -- Redwolf Fang
		T3 = {215, 216} -- Pointed Fang and Sinister Fang
	},
	Mineral = {
		T1 = {195, 196, 197}, -- Copper Ore, Silver Ore, and Gold Ore
		T2 = {199, 200, 201}, -- Southron Iron, Copperstone, and Whitecobble
		T3 = {198, 202} -- Fuligin Ore and Sunstone
	},
	Undead = {
		T1 = {244}, -- Scrap Iron
		T2 = {233, 234}, -- Putrid Gold Tooth and Silver Crown
		T3 = {245, 269} -- Fell-Lord's Bone and Cursed Dullahan Bone
	},
	Matter = {
		T1 = {247, 259}, -- Greenish Slime and Magick Medal
		T2 = {248, 258}, -- Oily Slime and Dappled Ore
		T3 = {249, 260} -- Foaming Slime and Electrum
	},
	Saurian = {
		T1 = {219, 375}, -- Saurian Scale and Saurian Tail
		T2 = {220, 221}, -- Asp Toxiscale and Rattler Rockscale
		T3 = {222, 223} -- Darkscale and Boltscale
	},
	Harpy = {
		T1 = {225}, -- Harpy Pinion
		T2 = {226, 227}, -- Poison Pinion and Twisted Pinion
		T3 = {228} -- Spurious Wing
	},
	Spectral = {
		T1 = {236, 240}, -- Miasmite and Black Crystal
		T2 = {237, 242}, -- Astracite and Wailing Crystal
		T3 = {238} -- Eldricite
	},
	Mythical = {
		T1 = {230, 261}, -- Minotaur Horn and Great Griffin Claw
		T2 = {231, 262}, -- Blackened Horn and Griffin Pinion
		T3 = {270, 277} -- Dragon Scale and Granite Medusa Bone
	},
	Grisly = {
		T1 = {250, 251}, -- Rugged Bone and Misshapen Eye
		T2 = {255, 266}, -- Ogre Spur and Freakish Mane
		T3 = {256, 267} -- Ogre Talon and Black Freakish Mane
	},
	Misc = {
		T1 = {203, 204, 208, 210, 281, 283}, -- Jagged Bone, Beast-Skin, Goblin Horn, Chopper Horn, Rabbit Pelt and Spider Venom Sac
		T2 = {205, 206, 209, 211, 282}, -- Monster Fang, Monster Hide, Slate-Colored Horn, Knacker Horn, Leapworm Skin
		T3 = {359} -- Wyrmslife Crystal
	},
	-- Items that are used as materials in special cases are placed below
	-- They're excluded from material assignment
	Uncategorized = { 
		T1 = {78, 85}, -- Wakestone Shard and Lantern Oil
		T2 = {77, 344, 345, 346}, -- Wakestone, Jasper, Onyx, and Tiger Eye
		T3 = {}
	}
}
	
constants.matTraits = {
	Fire = {
		T1 = {251}, -- Misshapen Eye (Bestiary *wink*)
		T2 = {248, 234}, -- Oily Slime and Silver Crown
		T3 = {222, 249} -- Darkscale and Foaming Slime
	},
	Ice = {
		T1 = {203}, -- Jagged Bone
		T2 = {237, 255}, -- Astracite and Ogre Spur (Bestiary *wink*)
		T3 = {228, 267} -- Spurious Wing and Black Freakish Mane
	},
	Thunder = {
		T1 = {261}, -- Great Griffin Claw
		T2 = {258, 262}, -- Dappled Ore (Bestiary *wink*) and Griffin Pinion
		T3 = {223, 260} -- Boltscale and Electrum
	},
	Holy = {
		T1 = {196}, -- Silver Ore 
		T2 = {201, 234}, -- Whitecobble and Silver Crown
		T3 = {202, 260} -- Sunstone and Electrum
	},
	Poison = {
		T1 = {283}, -- Spider Venom Sac
		T2 = {220, 226}, -- Asp Toxiscale and Poison Pinion 
		T3 = {270} -- Granite Medusa Bone
	},
	Sleep = {
		T1 = {225}, -- Harpy Pinion
		T2 = {266}, -- Freakish Mane
		T3 = {215, 267} -- Pointed Fang and Black Freakish Mane
	},
	Silence = {
		T1 = {203, 240}, -- Jagged Bone and Black Crystal
		T2 = {242, 266}, -- Wailing Crystal and Freakish Mane
		T3 = {277} -- Dragon Scale
	},
	Petrify = {
		T1 = {259}, -- Magick Medal
		T2 = {221, 258}, -- Rattler Rockscale and Dappled Ore
		T3 = {199, 222, 270} -- Fuligin Ore, Darkscale and Granite Medusa Bone
	},
	Wet = {
		T1 = {247}, -- Greenish Slime
		T2 = {219, 375}, -- Saurian Scale and Saurian Tail
		T3 = {223} -- Boltscale
	},
	Tar = {
		T1 = {85}, -- Lantern Oil
		T2 = {248}, -- Oily Slime
		T3 = {222, 249} -- Darkscale and Foaming Slime
	},
	Multi = {
		T1 = {203, 204, 244}, -- Jagged Bone, Beast-Skin, and Scrap Iron
		T2 = {205, 206, 266}, -- Monster Hide, Monster Fang, and Freakish Mane
		T3 = {267, 277} -- Black Freakish Mane and Dragon Scale
	},
	Immortal = {
		T1 = {78, 240}, -- Wakestone Shard and Black Crystal
		T2 = {77, 242}, -- Wakestone and Wailing Crystal
		T3 = {269} -- Cursed Dullahan Bone
	},
	Treasure = {
		T1 = {259}, -- Magick Medal
		T2 = {344, 345, 346}, -- Jasper, Onyx, and Tiger Eye
		T3 = {260} -- Electrum
	},
	Power = {
		T1 = {230, 240, 251}, -- Minotaur Horn, Black Crystal, and Misshapen Eye
		T2 = {255, 262, 266}, -- Ogre Spur, Griffin Pinion, and Freakish Mane
		T3 = {269, 270, 277} -- Cursed Dullahan Bone, Granite Medusa Bone, and Dragon Scale
	}
}

constants.bossMats = {216, 215, 245, 259, 258, 260, 240, 242, 269, 261, 262, 277, 230, 231, 270, 251, 266, 267, 250, 255, 256}
constants.abundantMats = {85, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 259, 359} -- Magick Medals and Wyrmslife Crystal are placed here because they drop in piles

return constants